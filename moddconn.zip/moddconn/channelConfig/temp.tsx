
// <FormDropdown
//                   name="moduleIds"
//                   value={moduleIds}
//                   placeholder="Select Module"
//                   options={modules}
//                   isMulti={true}
//                   onChange={(selected: any) => {
//                     setModuleIds(selected);
//                   }}
// ></FormDropdown>


// const fetchProductModules = async (
//     filterModel: TFilterModel,
//     productIds?: any
//   ) => {
//     try {
//       let ids = [];
//       for (const product of productIds as any[]) {
//         ids.push(product.value);
//       }
//       const payload = {
//         filterModel: filterModel,
//         data: {},
//         productIds: ids ? ids : 0,
//       };
//       setLoading(true);
//       const response = await post(ApiGetProductModuleList, payload);
//       if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
//         const moduleList = response.data.map((module: any) => ({
//           value: module.id,
//           label: module.moduleName,
//         }));
//         setProductModules(moduleList);
//         setFilter(response.filterModel);
//       } else {
//         console.error("API response does not contain data:", response);
//       }
//     } catch (error) {
//       console.error("Encountered Error! While fetching modules- ", error);
//     } finally {
//       setLoading(false);
//     }
//   };