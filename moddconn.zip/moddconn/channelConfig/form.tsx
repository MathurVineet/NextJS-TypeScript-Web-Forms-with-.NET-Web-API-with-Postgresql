import React, { useEffect, useState } from "react";
import * as yup from "yup";
import data from "./data.json";
import { useDrawer, useFetch, useModal } from "@/hooks";
import classnames from "classnames";
import CommonUtil from "@/utils/common";
import { yupResolver } from "@hookform/resolvers/yup";
import { FaEdit, FaPlus, FaRegFileAlt, FaTimes } from "react-icons/fa";
import DashboardLayout from "@/components/layout/dashboard";
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Resolver, SubmitHandler, useForm } from "react-hook-form";
import {
  faEllipsisV,
  faSave,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import { INPUT_LENGTH, Regex, Validation_Messages } from "@/utils/validation";
import {
  Accordion,
  AccordionSection,
  Button,
  Form,
  FormRow,
  FormInput,
  FormDropdown,
  DatePicker,
  Table,
  TableBody,
  TableColumn,
  TableHead,
  DropdownOptionType,
  TableRow,
  FormContent,
  FormCheckbox,
  FormFooter,
  FormHeader,
  RadioOptionType,
  FormRadio,
  Popup,
} from "opexee-ui-library";
import type { MultiValue, OnChangeValue, SingleValue } from "react-select";
import { eCdCOM, eResultCode } from "@/utils/enum";
import {
  ApiGetCDcomList,
  ApiAddEditCD_com,
  ApiGetCD_comById,
} from "@/utils/api.constant";
//for using local-deployed api's
//import { BASEURLENGG } from "@/utils/api";
import { log } from "console";
import { closeRightSidebar } from "@/state/dashboard/slice";
type DrawerProps = {
  id: number;
  isOpen?: any;
  onClose?: any;
};
type DrawerFormModel = {
  id?: number;
  mbDsnCode: string;
  chType: string;
  serialPort?: string;
  baudRate?: string;
  dataFlow?: string;
  parity?: string;
  dataBit?: string;
  stopBit?: string;
  delayBetPoll?: number | undefined;
  mode?: string;
  tcp?: string | undefined;
  port?: number | undefined;
};
export default function TableDrawerForm(props: DrawerProps) {
  const { onCloseDrawer } = useDrawer();
  const { onShowModal } = useModal();
  const { post } = useFetch(); //
  const [comportdropdownOptions, setcomportdropdownOptions] = useState([]);
  const [baudratedropdownOptions, setbaudratedropdownOptions] = useState([]);
  const [flowdropdownOptions, setcflowdropdownOptions] = useState([]);
  const [paritydropdownOptions, setparitydropdownOptions] = useState([]);
  const [datadropdownOptions, setdatadropdownOptions] = useState([]);
  const [stopBitsdropdownOptions, setstopBitsdropdownOptions] = useState([]);
  const [modedropdownOptions, setmodedropdownOptions] = useState([]);
  const [ChTypedropdownOptions, setChTypedropdownOptions] = useState([]);

  const initialValue: DrawerFormModel = {
    id: 0,
    mbDsnCode: "",
    chType: "",
    serialPort: "",
    baudRate: "",
    dataFlow: "",
    parity: "",
    dataBit: "",
    stopBit: "",
    mode: "",
    delayBetPoll: 0,
    tcp: undefined,
    port: 0,
  };

  const validateSerial: any = (value: any) => {
    if (formValues.chType == "serial") {
      console.log(
        "formValues.chType?.value==serial",
        formValues.chType == "serial"
      );
      return value != undefined && value != null && value != "";
    }
    return true;
  };
  const validateSerialDelayPoll: any = (value: any) => {
    if (formValues.chType == "serial") {
      console.log(
        "formValues.chType?.value==serial",
        formValues.chType == "serial"
      );
      return value != undefined && value != null && value != "" && value > 10;
    }
    return true;
  };
  const validatTcpadd: any = (value: any) => {
    console.log("tcpvalue", value);
    if (formValues.chType == "tcpip") {
      console.log(
        "formValues.chType?.value==tcpip",
        formValues.chType == "tcpip"
      );
      return value != undefined && value != null && value.length > 0;
    }
    return true;
  };
  const validatTcpPort: any = (value: any) => {
    console.log("tcpvalue", value);
    if (formValues.chType == "tcpip") {
      console.log(
        "formValues.chType?.value==tcpip",
        formValues.chType == "tcpip"
      );
      return value != undefined && value != null && value > 0 && value != "";
    }
    return true;
  };
  const validationSchema = yup.object({
    //return true when you don't want to throw an error.

    chType: yup.string().test({
      test: (value: any) => value != undefined && value != null && value != "",
      message: "Please select type",
    }),

    serialPort: yup
      .string()
      .test("is-required-if", "Please select source column", validateSerial),
    baudRate: yup
      .string()
      .test("is-required-if", "Please select a baudRate.", validateSerial),
    dataFlow: yup
      .string()
      .test("is-required-if", "Please select a dataFlow.", validateSerial),
    parity: yup
      .string()
      .test("is-required-if", "Please select a parity.", validateSerial),
    dataBit: yup
      .string()
      .test("is-required-if", "Please select a dataBit.", validateSerial),
    stopBit: yup
      .string()
      .test("is-required-if", "Please select a stopBit.", validateSerial),
    mode: yup
      .string()
      .test("is-required-if", "Please select a mode.", validateSerial),
    delayBetPoll: yup
      .number()
      .test(
        "is-required-if",
        "Please select a delayBetPoll.",
        validateSerialDelayPoll
      ),
    tcp: yup
      .string()
      .test("is-required-if", "Please select a tcp.", validatTcpadd),
    port: yup
      .number()
      .test("is-required-if", "Please select a port.", validatTcpPort),
  });

  const {
    register,
    getValues,
    setValue,
    reset,
    setFocus,
    handleSubmit,
    clearErrors,
    formState: { errors, isSubmitting },
  } = useForm<DrawerFormModel>({
    mode: "all",
    defaultValues: initialValue,
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<DrawerFormModel>,
  });

  useEffect(() => {
    setFocus("chType");
    getComList(eCdCOM.COMPORT);
    getComList(eCdCOM.Baudrate);
    getComList(eCdCOM.Flow);
    getComList(eCdCOM.Parity);
    getComList(eCdCOM.Data);
    getComList(eCdCOM.StopBits);
    getComList(eCdCOM.Mode);
    getComList(eCdCOM.CommunicationType);
    //getComListByID(35);
  }, []);

  const getComList = async (id: eCdCOM) => {
    try {
      const payload = {
        data: {
          actionId: id,
        },
      };
      const response = await post(ApiGetCDcomList, payload);
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        const options = response.data.map(
          (item: { name: string; shortCode: string }) => ({
            label: item.name,
            value: item.shortCode,
          })
        );
        switch (id) {
          case eCdCOM.COMPORT:
            setcomportdropdownOptions(options);
            break;
          case eCdCOM.Baudrate:
            setbaudratedropdownOptions(options);
            break;
          case eCdCOM.Flow:
            setcflowdropdownOptions(options);
            break;
          case eCdCOM.Parity:
            setparitydropdownOptions(options);
            break;
          case eCdCOM.Data:
            setdatadropdownOptions(options);
            break;
          case eCdCOM.StopBits:
            setstopBitsdropdownOptions(options);
            break;
          case eCdCOM.Mode:
            setmodedropdownOptions(options);
            break;
          case eCdCOM.CommunicationType:
            setChTypedropdownOptions(options);
            break;
          default:
            console.error("Unknown id:", id);
        }
        return options;
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };

  const getComListByID = async (id: number) => {
    try {
      const payload = {
        data: {
          id: id,
        },
      };
      const response = await post(ApiGetCD_comById, payload);
      const { data } = response;
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        console.log("API response:", response);
        console.log("Response data:", data[0]);
        reset(data[0]);
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };

  const formValues = getValues();

  const setFieldValue = (key: any, value: any) => {
    setValue(key, value, {
      shouldValidate: true,
      shouldTouch: true,
    });
  };

  const onChTypeChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("chType", (selected as DropdownOptionType)?.value as string);
    clearErrors();
    console.log((selected as SingleValue<DropdownOptionType>)?.label);
    console.log("formValues.chType", formValues.chType);
  };

  const onComportChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue(
      "serialPort",
      (selected as DropdownOptionType)?.value as string
    );
  };

  const onBaudrateChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue(
      "baudRate",
      (selected as DropdownOptionType)?.value as string
    );
  };

  const onFlowChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue(
      "dataFlow",
      (selected as DropdownOptionType)?.value as string
    );
  };

  const onParityChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("parity", (selected as DropdownOptionType)?.value as string);
  };

  const onDataChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("dataBit", (selected as DropdownOptionType)?.value as string);
  };

  const onStopBitsChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("stopBit", (selected as DropdownOptionType)?.value as string);
  };

  const onModeChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("mode", (selected as DropdownOptionType)?.value as string);
  };

  const onSubmit: SubmitHandler<DrawerFormModel> = async (
    values: DrawerFormModel
  ) => {
    try {
      console.log("onSubmit values", values);
      const payload = {
        data: {
          Id: values.id,
          //mbDsnCode: values.mbDsnCode.value,
          chType: values.chType,
          serialPort: values.serialPort,
          baudRate: values.baudRate,
          dataFlow: values.dataFlow,
          parity: values.parity,
          dataBit: values.dataBit,
          stopBit: values.stopBit,
          delayBetPoll: values.delayBetPoll,
          mode: values.mode,
          tcp: values.tcp,
          port: values.port,
        },
      };
      console.log("data:", payload);
      const response = await post(ApiAddEditCD_com, payload);
      console.log("response", response);
    } catch (error) {
      console.error("Error ! While submitting form - ", error);
    }
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)} classNames="formBorder">
      <FormHeader
        classNames="formHeaderBorder"
        icon={<FaRegFileAlt color="#54c1bd" />}
      >
        Communication Type
      </FormHeader>
      <FormContent classNames="formContentBackground">
        <FormRow classNames="border-bottom">
          <FormDropdown
            name="ChType"
            classNames="hoverDropdown"
            isSearchable={false}
            label="Communication Type :"
            value={{
              value: formValues.chType,
              label: "",
            }}
            options={ChTypedropdownOptions}
            error={errors.chType?.message as string}
            placeholder="Select Communication Type"
            onChange={onChTypeChangeOrCreate}
            //onBlur={() => {trigger("Comport")}}
          ></FormDropdown>
        </FormRow>

        {formValues.chType == "serial" ? (
          <>
            <FormRow classNames="border-bottom">
              <FormDropdown
                name="comport"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Comport :"
                value={{
                  value: formValues.serialPort,
                  label: "",
                }}
                options={comportdropdownOptions}
                error={errors.serialPort?.message as string}
                placeholder="Select Comport"
                onCreateOption={onComportChangeOrCreate}
                onChange={onComportChangeOrCreate}
                // onChange={(event:any)=>{getComList()}}
                //onBlur={() => trigger("baudrate");}
              ></FormDropdown>
              <FormDropdown
                name="baudrate"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Baudrate :"
                value={{
                  value: formValues.baudRate,
                  label: "",
                }}
                options={baudratedropdownOptions}
                error={errors.baudRate?.message as string}
                placeholder="Select Baudrate"
                onCreateOption={onBaudrateChangeOrCreate}
                onChange={onBaudrateChangeOrCreate}
                //onBlur={() => {trigger("state");}}
              ></FormDropdown>
            </FormRow>
            <FormRow classNames="border-bottom">
              <FormDropdown
                name="flow"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Flow :"
                value={{
                  value: formValues.dataFlow,
                  label: "",
                }}
                options={flowdropdownOptions}
                error={errors.dataFlow?.message as string}
                placeholder="Select Flow"
                onCreateOption={onFlowChangeOrCreate}
                onChange={onFlowChangeOrCreate}
                //onBlur={() => trigger("country")}
              ></FormDropdown>
              <FormDropdown
                name="parity"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Parity :"
                value={{
                  value: formValues.parity,
                  label: "",
                }}
                options={paritydropdownOptions}
                error={errors.parity?.message as string}
                placeholder="Select Parity"
                onCreateOption={onParityChangeOrCreate}
                onChange={onParityChangeOrCreate}
                //onBlur={() => {trigger("state");}}
              ></FormDropdown>
            </FormRow>
            <FormRow classNames="border-bottom">
              <FormDropdown
                name="data"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Data :"
                value={{
                  value: formValues.dataBit,
                  label: "",
                }}
                options={datadropdownOptions}
                error={errors.dataBit?.message as string}
                placeholder="Select Data"
                onCreateOption={onDataChangeOrCreate}
                onChange={onDataChangeOrCreate}
                //onBlur={() => trigger("country")}
              ></FormDropdown>
              <FormDropdown
                name="stopBits"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Stop Bits :"
                value={{
                  value: formValues.stopBit,
                  label: "",
                }}
                options={stopBitsdropdownOptions}
                error={errors.stopBit?.message as string}
                placeholder="Select Stop Bits"
                onCreateOption={onStopBitsChangeOrCreate}
                onChange={onStopBitsChangeOrCreate}
                // onBlur={() => {trigger("state");}}
              ></FormDropdown>
            </FormRow>
            <FormRow classNames="border-bottom">
              <FormInput
                label="Delay Bet Poll :"
                error={errors.delayBetPoll?.message}
                name="delayBetPoll"
                id="delayBetPoll"
                register={register}
                placeholder="Enter Delay Bet Poll"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
              <FormDropdown
                name="mode"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Mode :"
                value={{
                  value: formValues.mode,
                  label: "",
                }}
                options={modedropdownOptions}
                error={errors.mode?.message as string}
                placeholder="Select Mode"
                onCreateOption={onModeChangeOrCreate}
                onChange={onModeChangeOrCreate}
                //onBlur={() => trigger("country")}
              ></FormDropdown>
            </FormRow>
          </>
        ) : (
          <>
            <FormRow classNames="border-bottom">
              <FormInput
                label="TCP/IP address:"
                error={errors.tcp?.message}
                name="tcp"
                id="tcp"
                register={register}
                placeholder="Enter TCP/IP address"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
              <FormInput
                label="TCP/IP PORT :"
                error={errors.port?.message}
                name="port"
                id="port"
                register={register}
                placeholder="Enter TCP/IP PORT"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
                onKeyDown={CommonUtil.validateNumber}
              ></FormInput>
            </FormRow>
          </>
        )}
      </FormContent>

      <FormFooter classNames="formFooterBackground">
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" />
            <span>Cancel</span>
          </Button>
          <Button
            type="submit"
            onClick={() => console.log(errors, "errors")}
            classNames="saveButton"
            isLoading={isSubmitting}
          >
            <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
            <span>&nbsp;Save</span>
          </Button>
        </FormRow>
      </FormFooter>
    </Form>
  );
}
TableDrawerForm.getLayout = DashboardLayout;
