/**
 * TableDrawerForm.tsx
 * This DrawerForm Component is used to display form like a Sidebar.
 */

import React, { useEffect } from "react";
import * as yup from "yup";
import data from "./data.json";
import { useDrawer, useModal } from "@/hooks";
import classnames from "classnames";
import CommonUtil from "@/utils/common";
import { yupResolver } from "@hookform/resolvers/yup";
import { FaEdit, FaPlus, FaRegFileAlt, FaTimes } from "react-icons/fa";
import DashboardLayout from "@/components/layout/dashboard";
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Resolver, SubmitHandler, useForm } from "react-hook-form";
import { faEllipsisV, faSave, faXmark } from "@fortawesome/free-solid-svg-icons";
import { INPUT_LENGTH, Regex, Validation_Messages } from "@/utils/validation";
import {
  Accordion,
  AccordionSection,
  Button,
  Form,
  FormRow,
  FormInput,
  FormDropdown,
  DatePicker,
  Table,
  TableBody,
  TableColumn,
  TableHead,
  DropdownOptionType,
  TableRow,
  FormContent,
  FormCheckbox,
  FormFooter,
  FormHeader,
  RadioOptionType,
  FormRadio,
  Popup,
} from "opexee-ui-library";
import type { MultiValue, OnChangeValue, SingleValue } from "react-select";

type DrawerProps = {
  id: number;
  isOpen?: any;
  onClose?: any;
};

type DrawerFormModel = {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  city?: SingleValue<DropdownOptionType>;
  state?: SingleValue<DropdownOptionType>;
  country?: SingleValue<DropdownOptionType>;
  agree: boolean;
  hobbies: MultiValue<DropdownOptionType>;
  marksList: Array<marks>;
  gender: RadioOptionType;
  locations?: MultiValue<DropdownOptionType>;
};

type marks = {
  id: number;
  name: string;
  s1: number;
  s2: number;
  course?: SingleValue<DropdownOptionType>;
};;

export default function TableDrawerForm(props: DrawerProps) {
  const { onCloseDrawer } = useDrawer();
  const { onShowModal } = useModal();

  const initialValue: DrawerFormModel = {
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    agree: false,
    hobbies: [],
    marksList: data.marks,
    gender: { value: "Female", label: "Female" },
    locations: [],
  };

  const addMarks = () => {
    const newItem = {
      id: 0,
      name: "",
      s1: 0,
      s2: 0,
    };
    const listdata = formValues?.marksList ? formValues.marksList : [];
    listdata.unshift(newItem);
    setFieldValue("marksList", listdata);
  };

  const validationSchema = yup.object({
    firstName: yup
      .string()
      .min(6, "First name must be at least 6 characters.")
      .max(20, "First name should not exceed 20 characters.")
      .required(Validation_Messages.required),
    lastName: yup
      .string()
      .min(6, "Last name must be at least 6 characters.")
      .max(20, "Last name should not exceed 20 characters.")
      .required(Validation_Messages.Required),
    email: yup
      .string()
      .min(6, Validation_Messages.Email_Min)
      .matches(Regex.EMAIL, Validation_Messages.Email_valid)
      .email(Validation_Messages.Email_valid)
      .required(Validation_Messages.Required),
    phone: yup
      .string()
      .min(10, Validation_Messages.Mobile_Number_Min)
      .max(10, Validation_Messages.Mobile_Number_Min)
      .matches(Regex.MOBILENO, Validation_Messages.Mobile_Number_Matches)
      .required(Validation_Messages.Required),
    hobbies: yup
      .array()
      .of(
        yup.object().shape({
          value: yup.number(),
          label: yup.string(),
        })
      )
      .min(1, "Please select at least one hobby.")
      .required(),
    country: yup
      .object({
        value: yup.number(),
        label: yup.string().min(1),
      })
      .test({
        test: (value) => value?.label !== "" && value.value != undefined,
        message: "Please select a country.",
      }),
    state: yup
      .object({
        value: yup.number(),
        label: yup.string().min(1),
      })
      .test({
        test: (value) => value?.label !== "" && value.value != undefined,
        message: "Please select a state.",
      }),
    city: yup
      .object({
        value: yup.number(),
        label: yup.string().min(1),
      })
      .test({
        test: (value) => value?.label !== "" && value.value != undefined,
        message: "Please select a city.",
      }),
    marksList: yup
      .array()
      .of(
        yup.object().shape({
          name: yup
            .string()
            .required("Please enter name.")
            .min(1, "Please enter name."),
          course: yup
            .object({
              value: yup.number(),
              label: yup.string().min(1),
            })
            .test({
              test: (value) => value?.label !== "" && value.value != undefined,
              message: "Please select a country.",
            }),
          s1: yup.number().min(1, Validation_Messages.required),
          s2: yup.number().min(1, Validation_Messages.required),
        })
      )
      .min(1, "Please add at least one record.")
      .required(),
    agree: yup
      .boolean()
      .oneOf(
        [true],
        "Please certify that the information is true and accurate by checking the box."
      )
      .required(),
  });

  const {
    register,
    getValues,
    setValue,
    trigger,
    setFocus,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<DrawerFormModel>({
    mode: "all",
    defaultValues: initialValue,
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<DrawerFormModel>,
  });

  useEffect(() => {
    setFocus("firstName");
  }, []);

  const formValues = getValues();

  const setFieldValue = (key: any, value: any) => {
    setValue(key, value, {
      shouldValidate: true,
      shouldTouch: true,
    });
  };

  const removeMarks = (index: number) => {
    const updatedList = formValues?.marksList ? formValues.marksList : [];
    updatedList.splice(index, 1);
    setFieldValue("marksList", updatedList);
  };

  const handleNameChange = (index: number, value: string) => {
    const newList = formValues?.marksList ? formValues.marksList : [];
    newList[index].name = value;
    setFieldValue("marksList", newList);
  };

  const handleSubjectFirstChange = (index: number, value: number) => {
    const newList = formValues?.marksList ? formValues?.marksList : [];
    newList[index].s1 = value;
    setFieldValue("marksList", newList);
  };

  const handleSubjectSecondChange = (index: number, value: number) => {
    const newList = formValues?.marksList ? formValues.marksList : [];
    newList[index].s2 = value;
    setFieldValue("marksList", newList);
  };

  const handleCourseChange = (
    index: number,
    value: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    const newList = formValues.marksList ? formValues.marksList : [];
    newList[index].course = value as SingleValue<DropdownOptionType>;
    setFieldValue("marksList", newList);
  };

  const handleGenderChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedGender = {
      value: event.target.value,
      label: event.target.value,
    };
    setFieldValue("gender", selectedGender);
  };

  const onHobbyChange = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("hobbies", selected);
  };

  const onCountryChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("country", selected);
  };

  const onStateChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("state", selected);
  };

  const onCityChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("city", selected);
  };

  const renderMarksList = () => {
    return formValues?.marksList?.map((item, index) => (
      <TableRow key={index}>
        <TableColumn classNames="w-[5%]" key={index} variant="centerAlign">
          {index + 1}
        </TableColumn>
        <TableColumn variant="centerAlign" classNames="!text-left !p-0">
          <FormInput
            error={errors.marksList?.[index]?.name?.message}
            name={item.name || ""}
            value={item.name || ""}
            placeholder="Enter first name"
            onChange={(data: any) => handleNameChange(index, data.target.value)}
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </TableColumn>
        <TableColumn
          variant="centerAlign"
          classNames="dropdownFormDropdown !text-left !p-0"
        >
          <FormDropdown
            value={item.course}
            options={data.courses}
            error={errors.marksList?.[index]?.course?.message as string}
            placeholder="Course"
            onChange={(selected: any) => {
              handleCourseChange(index, selected);
            }}
          ></FormDropdown>
        </TableColumn>
        <TableColumn variant="centerAlign" classNames="dateColumn !pt-0 !pb-0">
          <DatePicker
            value={new Date()} />
        </TableColumn>
        <TableColumn classNames="!text-left !p-0">
          <FormInput
            error={errors.marksList?.[index]?.s1?.message}
            placeholder="Enter marks"
            name={formValues?.marksList?.[index]?.s1.toString() || ""}
            value={formValues?.marksList?.[index]?.s1 || ""}
            register={register}
            onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
              handleSubjectFirstChange(index, parseInt(event?.target?.value))
            }
            maxLength={INPUT_LENGTH.MARKS_LENGTH}
            onKeyDown={CommonUtil.validateText}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </TableColumn>
        <TableColumn classNames="!text-left !p-0">
          <FormInput
            error={errors.marksList?.[index]?.s2?.message}
            placeholder="Enter marks"
            name={formValues?.marksList?.[index]?.s2.toString() || ""}
            value={formValues?.marksList?.[index]?.s2 || ""}
            register={register}
            onChange={(data: any) => handleSubjectSecondChange(index, data?.target?.value)}
            maxLength={INPUT_LENGTH.MARKS_LENGTH}
            onKeyDown={CommonUtil.validateText}
            onKeyPress={CommonUtil.validateEnterKey}
          />
        </TableColumn>
        <TableColumn
          variant="centerAlign"
          classNames=""
        >
          <FaTimes
            color="rgb(128 133 137)"
            onClick={() => removeMarks(index)}
            title="Delete"
            className="cursorPointer"
          />
        </TableColumn>
      </TableRow>
    ));
  };

  const onSubmit: SubmitHandler<DrawerFormModel> = async (
    values: DrawerFormModel
  ) => {
    try {
      const formData = {
        firstName: values.firstName,
        lastName: values.lastName,
        email: values.email,
        phone: values.phone,
        hobbies: values.hobbies,
        locations: values.locations,
        gender: values.gender,
        country: formValues.country,
        state: values.state,
        city: values.city,
        agree: values.agree,
        marksList: values.marksList,
      };
    } catch (error) {
      console.error("Error ! While submitting form - ", error);
    }
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)} classNames="formBorder">
      <FormHeader classNames="formHeaderBorder" icon={<FaRegFileAlt color="#54c1bd" />}>
        Drawer Form
        {/* <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" />
            <span>Cancel</span>
          </Button>
          <Button
            type="submit"
            classNames="saveButton"
            isLoading={isSubmitting}
          >
            <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
            <span>&nbsp;Save</span>
          </Button>
          <div className=" bg-primary  font-sans font-medium d-flex text-white items-center gap-2 px-2 py-1 text-xs rounded-sm">
            Action
            <Popup icon={faEllipsisV}>
              <ul className={classnames("arrowPointer", "actionButtons")}>
                <li className="actions" >
                  <FaEdit color="#396077" />
                  Edit
                </li>
                <li
                  className="actions"
                  onClick={() => {
                    onShowModal({
                      content: "Are you sure you want to delete this record?",
                      showButton: true,
                    });
                  }}
                >
                  <img src="/assets/images/googleTrash.svg" alt="" />
                  Delete
                </li>
              </ul>
            </Popup></div>
        </FormRow> */}
      </FormHeader>
      <FormContent classNames="formContentBackground">
        <Accordion>
          <AccordionSection
            className="accordion-section"
            title="Personal Details"
            error={CommonUtil.sectionError([
              "firstName",
              "lastName",
              "email",
              "phone",
              "hobbies",
            ], errors)}
          >
            <FormRow classNames="border-bottom">
              <FormInput
                label="First Name :"
                error={errors.firstName?.message}
                name="firstName"
                id="firstName"
                register={register}
                placeholder="First name"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
              <FormInput
                label="Last Name :"
                error={errors.lastName?.message}
                name="lastName"
                register={register}
                placeholder="Last name"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
            </FormRow>
            <FormRow classNames="border-bottom">
              <FormInput
                label="Email :"
                error={errors.email?.message}
                name="email"
                register={register}
                placeholder="Email id"
                maxLength={INPUT_LENGTH.EMAIL_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
              <FormInput
                label="Phone No. :"
                error={errors.phone?.message}
                name="phone"
                register={register}
                placeholder="Phone number"
                maxLength={INPUT_LENGTH.MOBILE_LENGTH}
                onKeyDown={CommonUtil.validateMobile}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
            </FormRow>
            <FormRow classNames="border-bottom">
              <FormDropdown
                name="hobbies"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Hobbies :"
                value={formValues.hobbies}
                options={data.hobbies}
                error={errors.hobbies?.message as string}
                isMulti={true}
                placeholder="Select hobbies"
                onChange={onHobbyChange}
                onBlur={() => {
                  trigger("hobbies");
                }}
              ></FormDropdown>
            </FormRow>
            <FormRow classNames="formGender border-bottom">
              <FormRadio
                label="Gender: "
                value={formValues.gender}
                options={data.genders}
                onChange={handleGenderChange}
              ></FormRadio>
            </FormRow>
          </AccordionSection>
          <AccordionSection
            className="accordion-section"
            title="Location Details"
            error={CommonUtil.sectionError(["country", "state", "city"], errors)}
          >
            <FormRow classNames="border-bottom">
              <FormDropdown
                name="country"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Country :"
                value={formValues.country}
                options={data.countries}
                error={errors.country?.message as string}
                placeholder="Select country"
                onCreateOption={onCountryChangeOrCreate}
                onChange={onCountryChangeOrCreate}
                onBlur={() => trigger("country")}
              ></FormDropdown>
              <FormDropdown
                name="state"
                isCreatable={true}
                classNames="hoverDropdown"
                label="State :"
                value={formValues.state}
                options={data.states}
                error={errors.state?.message as string}
                placeholder="Select state"
                onCreateOption={onStateChangeOrCreate}
                onChange={onStateChangeOrCreate}
                onBlur={() => {
                  trigger("state");
                }}
              ></FormDropdown>
            </FormRow>
            <FormRow classNames="border-bottom">
              <FormDropdown
                name="city"
                isCreatable={true}
                classNames="hoverDropdown"
                label="City :"
                value={formValues.city}
                options={data.cities}
                error={errors.city?.message as string}
                placeholder="Select city"
                onCreateOption={onCityChangeOrCreate}
                onChange={onCityChangeOrCreate}
                onBlur={() => {
                  trigger("city");
                }}
              ></FormDropdown>
            </FormRow>
          </AccordionSection>
          <AccordionSection
            className="accordion-section"
            title="Academic Details"
            error={CommonUtil.sectionError(["marksList"], errors)}
          >
            <div className="formTable">
              <Table classNames="editableTable">
                <TableRow>
                  <TableHead
                    variant="centerAlign"
                    width="5%"
                    classNames={classnames("editableTableHead", "!pl-[10px]")}
                  >
                    Sr
                  </TableHead>
                  <TableHead
                    width="25%"
                    classNames={classnames("editableTableHead", "!pl-[10px]")}
                  >
                    Student Name
                  </TableHead>
                  <TableHead
                    width="17%"
                    classNames={classnames("editableTableHead", "!pl-[10px]")}
                  >
                    Course
                  </TableHead>
                  <TableHead
                    width="15%"
                    classNames={classnames("editableTableHead", "!pl-[8px]")}
                  >
                    Year
                  </TableHead>
                  <TableHead
                    width="13%"
                    classNames={classnames("editableTableHead", "!pl-[10px]")}
                  >
                    S1
                  </TableHead>
                  <TableHead
                    width="17%"
                    classNames={classnames("editableTableHead", "!pl-[8px]")}
                  >
                    S2
                  </TableHead>
                  <TableHead
                    variant="rightAlign"
                    width="13%"
                    classNames={classnames("editableTableHead ")}
                  >
                    <Button
                      data-title={
                        errors.marksList?.message
                          ? errors.marksList?.message
                          : "Add"
                      }
                      classNames={classnames({
                        ["disabled-button"]: !errors.marksList?.message
                      }, '!bg-white !p-0')}
                      onClick={() => addMarks()}
                    >
                      <FaPlus
                        color={errors.marksList?.message
                          ? "#ec4a3d"
                          : "#396077"}
                      />
                    </Button>
                  </TableHead>
                </TableRow>
                <TableBody>{renderMarksList()}</TableBody>
              </Table>
            </div>
          </AccordionSection>
        </Accordion>
        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={
              "I hereby certify that, the provided information is true and accurate."
            }
            error={errors.agree?.message}
            checked={formValues.agree}
            name="agree"
            register={register}
            onChange={() => {
              setFieldValue("agree", !formValues.agree);
            }}
          ></FormCheckbox>
        </FormRow>
      </FormContent>
      <FormFooter classNames="formFooterBackground">
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" />
            <span>Cancel</span>
          </Button>
          <Button
            type="submit"
            classNames="saveButton"
            isLoading={isSubmitting}
          >
            <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
            <span>&nbsp;Save</span>
          </Button>
        </FormRow>
      </FormFooter>
    </Form>
  );
}

TableDrawerForm.getLayout = DashboardLayout;
