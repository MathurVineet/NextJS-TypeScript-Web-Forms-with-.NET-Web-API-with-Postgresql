import React, { useState } from 'react';
import Table, { ColumnType } from 'rc-table';
import { FaCaretDown, FaCaretRight, FaPlus, FaEdit, FaTrash } from 'react-icons/fa';
// import { Search } from '@/components/search/search';

interface DataType {
  key: string;
  name: string;
  age: number;
  address: string;
  children?: DataType[];
}

type Key = string | number;

interface TExpandIconProps {
  expanded: boolean;
  onExpand: (record: DataType, expanded: boolean) => void;
  record: DataType;
}

const columns: ColumnType<DataType>[] = [
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    width: 250,
  },
  {
    title: 'Full Path',
    dataIndex: 'fullPath',
    key: 'fullPath',
    width: 400,
  },
  {
    title: 'Data Type',
    dataIndex: 'dataType',
    key: 'dataType',
    width: 150,
  },
  {
    title: 'Value',
    dataIndex: 'value',
    key: 'value',
    width: 150,
  },
  {
    title: 'Description',
    dataIndex: 'description',
    key: 'description',
    width: 450,
  },
  {
    title: 'Operations',
    dataIndex: '',
    key: 'operations',
    width: 100,
    render: (text, record) => (
      <span className="flex space-x-2">
        <FaPlus className="cursor-pointer" style={{ color: 'rgb(246, 246, 246)' }} title="Add" />
        <FaEdit className="cursor-pointer" style={{ color: 'rgb(246, 246, 246)' }} title="Edit" />
        <FaTrash className="cursor-pointer" style={{ color: 'rgb(246, 246, 246)' }} title="Delete" />
      </span>
    ),
  },
];

const data: DataType[] = [
  {
    name: 'Node1',
    age: 28,
    address: 'some where',
    key: '1',
    children: [
      {
        name: 'Node1A',
        age: 28,
        address: 'some where',
        key: '3',
      },
      {
        name: 'Node1B',
        age: 28,
        address: 'some where',
        key: '4',
      },
    ],
  },
  { name: 'Node2', age: 36, address: 'some where', key: '2' },
  { name: 'Node3', age: 36, address: 'some where', key: '5' },
  {
    name: 'Node4',
    age: 28,
    address: 'some where',
    key: '6',
    children: [
      {
        name: 'Node4A',
        age: 28,
        address: 'some where',
        key: '7',
      },
      {
        name: 'Node4B',
        age: 28,
        address: 'some where',
        key: '8',
      },
    ],
  },
  { name: 'Node5', age: 36, address: 'some where', key: '9' },
  { name: 'Node6', age: 36, address: 'some where', key: '10' },
];

const RcTableComponent: React.FC = () => {
  const [expandedRows, setExpandedRows] = useState<Key[]>([]);
  const [searchText, setSearchText] = useState('');

  const renderExpandIcon = ({
    expanded,
    onExpand,
    record,
  }: TExpandIconProps) => {
    if (record.children && record.children.length > 0) {
      return (
        <span
          className="cursor-pointer"
          onClick={(e) => {
            e.stopPropagation();
            onExpand(record, !expanded);
          }}
        >
          {expanded ? <FaCaretDown /> : <FaCaretRight />}
        </span>
      );
    } else {
      return null;
    }
  };

  const handleSearch = () => {
    console.log('Searching for:', searchText);
  };

  return (
    <div>
      {/* <div className="table-header">
        <label className="mx-500">Table Name</label>
          <input
            type="text"
            placeholder="Search..."
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            className="search-input"
          />
          <button className="search-button" onClick={handleSearch}>
            Search
          </button>
      </div> */}
      <Table
      className='w-full'
        columns={columns}
        data={data}
        rowKey="key"
        expandable={{
          expandedRowKeys: expandedRows,
          onExpand: (expanded, record) => {
            setExpandedRows(
              expanded
                ? [...expandedRows, record.key]
                : expandedRows.filter((key) => key !== record.key)
            );
          },
          expandIcon: renderExpandIcon,
          rowExpandable: (record) => !!record.children,
        }}
        rowClassName={(record, index) =>
          record.children && record.children.length > 0
            ? 'bg-gray-100'
            : 'bg-white'
        }
        indentSize={20}
      />
    </div>
  );
};

export default RcTableComponent;
