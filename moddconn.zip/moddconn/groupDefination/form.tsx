/**
 * TableDrawerForm.tsx
 * This DrawerForm Component is used to display form like a Sidebar.
 */

import React, { useEffect, useState } from "react";
import * as yup from "yup";
import data from "./data.json";
import { useDrawer, useModal, useFetch } from "@/hooks";
import classnames from "classnames";
import CommonUtil from "@/utils/common";
import { yupResolver } from "@hookform/resolvers/yup";
import { FaEdit, FaPlus, FaRegFileAlt, FaTimes } from "react-icons/fa";
import DashboardLayout from "@/components/layout/dashboard";
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Resolver, SubmitHandler, useForm } from "react-hook-form";
import {
  faEllipsisV,
  faSave,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import { INPUT_LENGTH, Regex, Validation_Messages } from "@/utils/validation";
import {
  Accordion,
  AccordionSection,
  Button,
  Form,
  FormRow,
  FormInput,
  FormDropdown,
  DatePicker,
  Table,
  TableBody,
  TableColumn,
  TableHead,
  DropdownOptionType,
  TableRow,
  FormContent,
  FormCheckbox,
  FormFooter,
  FormHeader,
  RadioOptionType,
  FormRadio,
  Popup,
} from "opexee-ui-library";
import type { MultiValue, OnChangeValue, SingleValue } from "react-select";
import { eResultCode } from "@/utils/enum";
import { ApiGetGroupById } from "@/utils/api.constant";

type DrawerProps = {
  id: number;
  isOpen?: any;
  onClose?: any;
};

type DrawerFormModel = {
  id: number;
  name: string;
  description: string;
};

export default function TableDrawerForm(props: DrawerProps) {
  const { onCloseDrawer } = useDrawer();
  const { onShowModal } = useModal();
  const { post } = useFetch();

  const initialValue: DrawerFormModel = {
    id: 0,
    name: "",
    description: "",
  };

  const validationSchema = yup.object({
    name: yup
      .string()
      .test(
        "is-required-if",
        "Please enter a name",
        (value) => value !== undefined && value !== null && value !== ""
      ),

    description: yup
      .string()
      .test(
        "is-required-if",
        "Please enter a description",
        (value) => value !== undefined && value !== null && value !== ""
      ),
  });

  const {
    register,
    getValues,
    setValue,
    trigger,
    setFocus,
    handleSubmit,
    clearErrors,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<DrawerFormModel>({
    mode: "all",
    defaultValues: initialValue,
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<DrawerFormModel>,
  });

  useEffect(() => {
    setFocus("name");
  }, []);

  const getComListByID = async (id: number) => {
    try {
      const payload = {
        data: {
          id: id,
        },
      };
      const response = await post(ApiGetGroupById, payload);
      const { data } = response;
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        console.log("API response:", response);
        console.log("Response data:", data[0]);
        reset(data[0]);
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };
  const formValues = getValues();

  const setFieldValue = (key: any, value: any) => {
    setValue(key, value, {
      shouldValidate: true,
      shouldTouch: true,
    });
  };

  const onSubmit: SubmitHandler<DrawerFormModel> = async (
    values: DrawerFormModel
  ) => {
    try {
      const formData = {
        id: values.id,
        name: values.name,
        description: values.description,
      };
    } catch (error) {
      console.error("Error ! While submitting form - ", error);
    }
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)} classNames="formBorder">
      <FormHeader
        classNames="formHeaderBorder"
        icon={<FaRegFileAlt color="#54c1bd" />}
      >
        Group Definition
      </FormHeader>
      {/* //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// */}
      <FormContent classNames="formContentBackground">
        <FormRow classNames="border-bottom">
          <FormInput
            label="Name :"
            error={errors.name?.message}
            name="name"
            id="name"
            register={register}
            placeholder="Enter Group Name"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
          <FormInput
            label="Description :"
            error={errors.description?.message}
            name="description"
            id="description"
            register={register}
            placeholder="Enter Group Description"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </FormRow>
      </FormContent>
      {/* //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// */}
      <FormFooter classNames="formFooterBackground">
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" />
            <span>Cancel</span>
          </Button>
          <Button
            type="submit"
            classNames="saveButton"
            isLoading={isSubmitting}
          >
            <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
            <span>&nbsp;Save</span>
          </Button>
        </FormRow>
      </FormFooter>
    </Form>
  );
}

TableDrawerForm.getLayout = DashboardLayout;
