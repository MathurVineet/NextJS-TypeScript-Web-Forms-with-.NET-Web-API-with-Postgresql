/**
 * MenuList.tsx
 * This MenuList Component is used to display List of the Menu Form.
 */

import React, { useState, useEffect, Key } from "react";
import Utils from "@/utils";
import Table from "rc-table";
import MenuForm from "./form";
import classnames from "classnames";
import { useRouter } from "next/router";
import { eConfigParam, eMenuType, eResultCode } from "@/utils/enum";
import { TFilterModel } from "@/types/config";
import {
  Button,
  Checkbox,
  PageHeader,
  Pagination,
  Popup,
  Search,
} from "opexee-ui-library";
import { filterDefaultValue } from "@/utils/constants";
import { ToastType } from "@/state/toast/slice";
import DashboardLayout from "@/components/layout/dashboard";
import { faEllipsisV, faTools } from "@fortawesome/free-solid-svg-icons";
import { useDrawer, useFetch, useToast, useModal } from "@/hooks";
import "rc-table/assets/index.css";
import {
  FaArrowDown,
  FaArrowUp,
  FaCaretDown,
  FaCaretRight,
  FaCaretUp,
  FaCheck,
  FaEdit,
  FaPlus,
  FaRegFileAlt,
  FaSearch,
  FaTimes,
} from "react-icons/fa";
import {
  ApiGetMenuHierarchyList,
  ApiRemoveMenu,
  ApiGetConfigParamList,
  ApiSwapMenuOrder,
} from "@/utils/api.constant";

type TDataItem = {
  id: number;
  key?: string;
  typeId: number;
  keyName: string;
  expanded: boolean;
  displayName: string;
  children?: any;
};

type TConfigData = {
  description: string;
  groupId: number;
  id: number;
  isDeleted: number;
  name: string;
};

type TRowItem = { index: number; path: number[] };

export default function Menu() {
  const router = useRouter();
  const { post } = useFetch();
  const { onShowToast } = useToast();
  const { onShowModal } = useModal();
  const [configData, setConfigData] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const { onShowDrawer } = useDrawer();
  const [data, setData] = useState([] as Array<TDataItem>);
  const [expandedRows, setExpandedRows] = useState<readonly Key[]>([]);
  const [selectedOption, setSelectedOption] = useState(1 as number);
  const [filterModel, setFilter] = useState<TFilterModel>({
    ...filterDefaultValue,
    ...router.query,
  });
  const [swappingIndex, setSwappingIndex] = useState<number | null>(null);

  useEffect(() => {
    if (router.isReady) {
      fetchMenuList({ ...filterModel, ...router.query });
    }
  }, [router.query]);

  const updateFilter = (newFilter: Record<string, any> = {}) => {
    const updatedFilter = {
      ...filterModel,
      ...newFilter,
    };
    const componentName = router.query.component?.[0];
    router.push({
      pathname: "/dashboard/" + componentName,
      query: Utils.getQueryString({
        toDate: updatedFilter.toDate,
        orderBy: updatedFilter.orderBy,
        fromDate: updatedFilter.fromDate,
        pageSize: updatedFilter.pageSize,
        orderType: updatedFilter.orderType,
        searchText: updatedFilter.searchText,
        currentPage: updatedFilter.currentPage,
      }),
    });
    setFilter(updatedFilter);
  };

  const findSearchNode = (data: TDataItem[], filterValue: string): TDataItem | null => {
    for (const record of data) {
      const type = record.displayName;
      if (type.includes(filterValue)) {
        return record;
      }
      if (record.children && record.children.length > 0) {
        const searchNode = findSearchNode(record.children, filterValue);
        if (searchNode) {
          return searchNode;
        }
      }
    }
    return null;
  };

  useEffect(() => {
    if (filterModel.searchText) {
      const searchNode = findSearchNode(data, filterModel.searchText);
      if (searchNode) {
        const searchNodeId = searchNode.id;
  
        if (searchNodeId) {
          const expandedRowKeys = getExpandedRowKeys(data, searchNodeId).map(String);
          setExpandedRows(expandedRowKeys);
        }
      }
    } else {
      setExpandedRows([]);
    }
  }, [data]);

  const getExpandedRowKeys = (data: TDataItem[], searchNodeId: number): number[] => {
    return data.reduce((keys: number[], record: TDataItem) => {
      let expandedChildrenKeys: number[] = [];
  
      if (record.children) {
        expandedChildrenKeys = getExpandedRowKeys(record.children, searchNodeId);
      }
  
      if (record.id !== searchNodeId) {
        keys = [...keys, record.id, ...expandedChildrenKeys];
      }
  
      return keys;
    }, []);
  };
  
  const generateRowKeys = (data: Array<TDataItem>) => {
    return data.map((item) => {
      if (item.children && item.children.length > 0) {
        item.children = generateRowKeys(item.children);
        item.key = item.id.toString();
      }
      return {
        ...item,
      };
    });
  };

  const renderExpandIcon = ({ expanded, onExpand, record }: any) => {
    const hasChildren = record.children && record.children.length > 0;
    const IconComponent = hasChildren ? (
      <span className="d-flex items-center mr-2"
        onClick={(event) => {
          event.stopPropagation();
          onExpand(record, !expanded);
        }}
      >
        {expanded ? (
          <FaCaretDown className="text-xs" />
        ) : (
          <FaCaretRight className="text-xs" />
        )}
      </span>
    ) : null;

    return (
      <>
        {IconComponent}
      </>
    );
  };

  const swapItems = (firstRowIndex: TRowItem, secondRowIndex: TRowItem) => {
    setData((prevData) => {
      // Create a copy of the previous data to avoid mutating state directly
      const newData = [...prevData];

      // Parent arrays of the items to be swapped
      const firstParent = firstRowIndex.path.length
        ? getItemByPath(newData, firstRowIndex.path)
        : newData;
      const secondParent = secondRowIndex.path.length
        ? getItemByPath(newData, secondRowIndex.path)
        : newData;

      // Swap the items in their respective parent arrays
      const temp = firstParent[firstRowIndex.index];
      firstParent[firstRowIndex.index] = secondParent[secondRowIndex.index];
      secondParent[secondRowIndex.index] = temp;

      // Return the updated data to update the state
      return newData;
    });
  };

  const getItemByPath = (items: TDataItem[], path: number[]) => {
    return path.reduce((acc, curr) => acc[curr].children!, items);
  };

  const moveItem = (id: number, direction: "up" | "down") => {
    // Find the index of the item to be moved
    const itemIndex = findItemIndex(id, data);

    // If itemIndex is not found, exit early
    if (!itemIndex) return;

    // Determine the path and current array where the item resides
    const path = itemIndex.path;
    const currentArray = getItemByPath(data, path);

    // Calculate the target index based on the direction
    const targetIndex =
      direction === "up" ? itemIndex.index - 1 : itemIndex.index + 1;

    // Check if the target index is out of bounds
    if (targetIndex < 0 || targetIndex >= currentArray.length) return;

    // Define the target item and the items being swapped
    const targetItem = { index: targetIndex, path };
    const currentItem = currentArray[itemIndex.index];
    const swappedItem = currentArray[targetIndex];

    // Set the index of the item currently being swapped
    setSwappingIndex(itemIndex.index);

    // Payload for swap operation
    handleSwapPayload(
      { id: currentItem.id, order: targetIndex + 1 },
      { id: swappedItem.id, order: itemIndex.index + 1 }
    );

    // Execute the swap operation in the data structure
    swapItems(itemIndex, targetItem);

    // Reset the swapping index after the swap operation
    setSwappingIndex(null);
  };

  const moveItemUp = (id: number) => moveItem(id, "up");
  const moveItemDown = (id: number) => moveItem(id, "down");

  const handleDelete = async (item: TDataItem) => {
    const hasChildren = item.children.length > 0;
    if (hasChildren) {
      onShowToast({
        type: ToastType.error,
        title: <FaTimes />,
        content: "This menu has children. Please delete the children first before deleting this menu.",
      });
      return;
    }
    try {
      const payload = {
        data: {
          id: item.id,
        },
      };
      setIsLoading(true);
      const response = await post(ApiRemoveMenu, payload);
      if (response.dataResponse.returnCode == eResultCode.SUCCESS) {
        onShowToast({
          type: ToastType.success,
          title: <FaCheck />,
          content: response.dataResponse.description,
        });
        fetchMenuList({ ...filterModel, ...router.query });
      } else {
        onShowToast({
          type: ToastType.error,
          title: <FaTimes />,
          content: response.dataResponse.description,
        });
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchConfigParams = async () => {
    try {
      const payload = {
        data: {
          groupId: eConfigParam.menu,
        },
      };
      setIsLoading(true);
      const response = await post(ApiGetConfigParamList, payload);
      if (response && Array.isArray(response.data)) {
        const transformedOptions = response.data.map((item: TConfigData) => ({
          value: item.id,
          label: item.name,
        }));
        setConfigData(transformedOptions);
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchMenuList = async (filterModel: TFilterModel): Promise<void> => {
    try {
      setIsLoading(true);
      const payload = {
        data: {
          typeId: selectedOption,
        },
        filterModel,
      };
      const response = await post(ApiGetMenuHierarchyList, payload);
      if (response.dataResponse.returnCode == eResultCode.SUCCESS) {
        setData(generateRowKeys(response.data));
      } else {
        onShowToast({
          type: ToastType.error,
          title: <FaTimes />,
          content: response.dataResponse.description,
        });
      }
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchConfigParams();
  }, []);

  useEffect(() => {
    fetchMenuList({ ...filterModel, ...router.query });
  }, [selectedOption]);

  const onHandleAddEdit = (id: number, parentId?: number) => {
    onShowDrawer({
      dimmer: true,
      width: "50%",
      name: "Show Drawer Form",
      onSuccess: () => {
        router.replace({
          query: { ...router.query },
        });
      },
      Component: () => <MenuForm id={id} parentId={parentId as number} />,
    });
  };

  const handleSwapPayload = async (
    firstRowIndex: { id: number; order: number },
    secondRowIndex: { id: number; order: number }
  ) => {
    try {
      const payload = {
        data: {
          swapModel: {
            sourceMenuId: firstRowIndex.id,
            destinationMenuId: secondRowIndex.id,
            sourceOrderId: firstRowIndex.order,
            destinationOrderId: secondRowIndex.order,
          },
        },
      };
      const response = await post(ApiSwapMenuOrder, payload);
      if (response.dataResponse.returnCode == eResultCode.SUCCESS) {
        onShowToast({
          type: ToastType.success,
          title: <FaCheck />,
          content: response.dataResponse.description,
        });
      } else {
        onShowToast({
          type: ToastType.error,
          title: <FaTimes />,
          content: response.dataResponse.description,
        });
      }
    } catch (error) { }
  };

  const findItemIndex = (
    id: number,
    items: TDataItem[],
    path: number[] = []
  ): TRowItem | null => {
    for (let i = 0; i < items.length; i++) {
      if (items[i].id === id) {
        return { index: i, path };
      }
      if (items[i].children) {
        const result = findItemIndex(id, items[i].children, [...path, i]);
        if (result) {
          return result;
        }
      }
    }
    return null;
  };

  const renderRowButtons = (item: TDataItem, index: number) => {

    const isFirstRow = index === 0;
    const isLastRow = index === data.length - 1
    return (
      <div className="text-center">
        <div className="flex justify-end">
          <>
            <FaArrowUp
              color="#396077"
              size={13}
              className={`cursor-pointer mx-1 transition-transform duration-500 ease-in-out ${isFirstRow ? "opacity-50 pointer-events-none" : ""
                }`}
              onClick={() => moveItemUp(item.id)}
            />
            <FaArrowDown
              color="#396077"
              size={13}
              className={`cursor-pointer mx-1 transition-transform duration-500 ease-in-out ${isLastRow ? "opacity-50 pointer-events-none" : ""
                } `}
              onClick={() => moveItemDown(item.id)}
            />
          </>
          <div className="pr-2 " onClick={() => onHandleAddEdit(0, item?.id)}>
            <FaPlus color="#396077" size={13} className="cursor-pointer" />
          </div>
          <div className="pr-2 " onClick={() => onHandleAddEdit(item?.id, 0)}>
            <FaEdit color="#396077" size={15} className="cursor-pointer" />
          </div>
          <div
            onClick={() => {
              onShowModal({
                content: `Are you sure you want to delete this ${item.displayName}?`,
                showButton: true,
                onSave: () => { handleDelete(item) },
              });
            }}
          >
            <img src="/assets/images/googleTrash.svg" alt="" />
          </div>
        </div>
      </div>
    );
  };

  const columns = [
    {
      title: "Name",
      dataIndex: "keyName",
      key: "keyName",
      width: 200,
    },
    {
      title: "Display Name",
      dataIndex: "displayName",
      key: "displayName",
      width: 200,
    },
    {
      title: "Menu Type",
      dataIndex: "menuType",
      key: "menuType",
      width: 200,
      render: (text: string, item: TDataItem) => {
        return item.typeId === eMenuType.Top ? "Top Menu" : "Side Menu";
      },
    },
    {
      title: (
        <div className="text-right">
          <Button
            type="button"
            classNames="!w-[100%] !bg-transparent border-none flex justify-end outline-none !p-0"
            onClick={() => onHandleAddEdit(0, 0)}
          >
            <FaPlus color="#396077" />
          </Button>
        </div>
      ),
      dataIndex: "action",
      key: "action",
      width: 75,
      render: (text: string, item: TDataItem, index: number) =>
        renderRowButtons(item, index),
    },
  ];

  return (
    <div className="pageBody font-sans">
      <PageHeader
        icon={<FaRegFileAlt />}
        title="Menu"
        size="large"
        classNames="tableForm sm:text-xs md:text-xs flex justify-between items-center gap-2"
      >
        <div className="w-[20%] font-sans font-medium">
          <Search
            classNames="py-1 !rounded-sm"
            iconClassNames="!text-xs !left-auto !right-4 !top-3.5"
            searchText={filterModel.searchText}
            icon={filterModel.searchText.length === 0 ? <FaSearch /> : null}
            onInputChange={(searchText: string) => updateFilter({ searchText })}
          />
        </div>
        <div className=" bg-primary  font-sans font-medium d-flex text-white items-center gap-2 px-2 py-1 text-xs rounded-sm">
        <Popup icon={faTools}>
          <ul className={classnames("arrowPointer", "actionButtons")}>
            <li className="actions">
              <FaEdit color="#396077" />
              Export as CSV
            </li>
          </ul>
        </Popup>
        </div>
      </PageHeader>
      <div className="listContainer">
        <div className="tableContainer">
          <Table
            columns={columns}
            data={data}
            rowKey="key"
            expandable={{
              expandedRowKeys: expandedRows,
              onExpandedRowsChange: setExpandedRows,
              expandIcon: renderExpandIcon,
            }}
          />
        </div>
      </div>
      <div className="footer">
        <Pagination
          classNames=""
          pageSize={10}
          filterRowsCount={filterModel.filterRowsCount}
          totalRows={filterModel.totalRows}
          currentPage={filterModel.currentPage}
          onPageChange={(currentPage: number) => updateFilter({ currentPage })}
          onPageSizeChange={(pageSize: number) => updateFilter({ pageSize })}
          orderBy={filterModel.orderBy}
          orderType={filterModel.orderType}
        />
      </div>
    </div>
  );
}

Menu.getLayout = DashboardLayout;
