/**
 * MenuForm.tsx
 * This MenuForm Component is used to display form like a Sidebar.
 */

import React, { ChangeEvent, useEffect, useRef, useState } from "react";
import * as yup from "yup";
import Utils from "@/utils";
import Image from "next/image";
import CommonUtil from "@/utils/common";
import { eConfigParam, eMenuType, eResultCode } from "@/utils/enum";
import { ToastType } from "@/state/toast/slice";
import { yupResolver } from "@hookform/resolvers/yup";
import { MultiValue, SingleValue } from "react-select";
import { useDrawer, useFetch, useToast } from "@/hooks";
import DashboardLayout from "@/components/layout/dashboard";
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Resolver, SubmitHandler, useForm } from "react-hook-form";
import { faSave, faSun, faXmark } from "@fortawesome/free-solid-svg-icons";
import { INPUT_LENGTH, Validation_Messages } from "@/utils/validation";
import { FaCheck, FaRegFileAlt, FaTimes, FaUpload } from "react-icons/fa";
import {
  ApiGetMenuById,
  ApiGetEntitiesList,
  ApiGetConfigParamList,
  ApiAddEditMenuHierarchy,
} from "@/utils/api.constant";
import {
  Form,
  Label,
  Button,
  Loader,
  FormRow,
  FormInput,
  Accordion,
  FormFooter,
  FormHeader,
  FormContent,
  FormDropdown,
  AccordionSection,
  DropdownOptionType,
} from "opexee-ui-library";
// import { Icons } from "@/icons";

type MenuFormProps = {
  id: number;
  parentId: number;
  isOpen?: boolean;
  onClose?: boolean;
};
type MenuFormModel = {
  id?: number;
  keyName: string;
  parentId?: number;
  menuIcon?: string;
  displayName: string;
  typeId?: DropdownOptionType;
  entityId?: DropdownOptionType;
};
type ConfigData = {
  id: number;
  name: string;
  groupId: number;
  isDeleted: number;
  description: string;
};
export default function MenuForm(props: MenuFormProps) {
  const { post, getApiEndpoint } = useFetch();
  const { onShowToast } = useToast();
  const { onCloseDrawer, onSuccessDrawer } = useDrawer();
  const [configParam, setConfigParam] = useState<DropdownOptionType[]>();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  // const defaultMenuIcon = Icons.defaultIconOfMenuHeader;
  const initialValue: MenuFormModel = {
    id: 0,
    parentId: 0,
    keyName: "",
    menuIcon: "",
    displayName: "",
  };
  const validationSchema = yup.object({
    id: yup.number(),
    keyName: yup.string().min(6),
    displayName: yup
      .string()
      .required(Validation_Messages.required)
      .min(4)
      .required(Validation_Messages.required),
    typeId: yup.object({
      value: yup.number(),
      label: yup.string().default(""),
    })
      .test({
        test: (value: any) => value.value != undefined,
        message: "Please select type",
      }),
    parentId: yup.number().required(),
  });
  const {
    reset,
    setValue,
    register,
    setFocus,
    getValues,
    handleSubmit,
    formState: { errors, isSubmitting, isLoading },
  } = useForm<MenuFormModel>({
    mode: "all",
    defaultValues: async () => {
      if (props.id) {
        const response = await fetchMenuData(props.id);
        return response;
      } else {
        return initialValue;
      }
    },
    resolver: yupResolver(validationSchema) as Resolver<MenuFormModel>,
  });
  const formValues = getValues();

  const setFieldValue = (key: any, value: any) => {
    setValue(key, value, {
      shouldValidate: true,
      shouldTouch: true,
    });
  };

  const fetchMenuData = async (id: number) => {
    try {
      const payload = { data: { id } };
      const response = await post(ApiGetMenuById, payload);
      if (response.dataResponse.returnCode == eResultCode.SUCCESS) {
        let specificMenuData = response.data[0];
        specificMenuData = {
          ...specificMenuData,
          typeId: {
            value: specificMenuData.typeId,
            label: "",
          },
          entityId: {
            value: specificMenuData.entityId,
            label: "",
          },
        };
        return specificMenuData;
      }
    } catch (error) {
      console.error(`Error! while fetching menu data: ${error}`);
    }
    return initialValue;
  };

  const getConfigParamList = async () => {
    try {
      const payload = { data: { groupId: eConfigParam.menu } }
      const response = await post(ApiGetConfigParamList, payload);
      if (response && Array.isArray(response.data)) {
        const transformedOptions = response.data.map((item: ConfigData) => ({
          value: item.id,
          label: item.name,
        }));
        setConfigParam(transformedOptions);
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error(`Error! while fetching menu data: ${error}`);
    }
  }

  // useEffect(() => {
  //   Utils.delaySetFocus("keyName", setFocus);
  //   getConfigParamList()
  // }, [setFocus]);

  const handleFileInputChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const maxSizeInBytes = 10 * 1024;
      if (file.size > maxSizeInBytes) {
        onShowToast({
          type: ToastType.error,
          title: "Error",
          content: "Please select an image file smaller than 10KB.",
        });
        event.target.value = "";
        setValue("menuIcon", "");
        return;
      }
      const reader = new FileReader();
      reader.onload = (event: ProgressEvent<FileReader>) => {
        const base64String = event.target?.result as string;
        const parts = base64String.split(",");
        if (parts.length === 2) {
          setFieldValue("menuIcon", parts[1]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit: SubmitHandler<MenuFormModel> = async (
    value: MenuFormModel
  ) => {
    try {
      const payload = {
        data: {
          id: props.id,
          typeId: value.typeId?.value,
          keyName: value.keyName,
          parentId: props.parentId,
          menuIcon: value.menuIcon,
          entityId: value.entityId?.value,
          displayName: value.displayName,
        },
      };
      const response = await post(ApiAddEditMenuHierarchy, payload);
      if (response.dataResponse.returnCode == eResultCode.SUCCESS) {
        onShowToast({
          type: ToastType.success,
          title: <FaCheck />,
          content: response.dataResponse.description,
        });
        onSuccessDrawer();
      } else {
        onShowToast({
          type: ToastType.error,
          title: <FaTimes />,
          content: response.dataResponse.description,
        });
      }
    } catch (error) {
      console.error("Error while submitting...", error);
    }
  };

  function onRemoveIcon(formValues: MenuFormModel) {
    formValues.menuIcon = "";
    reset(formValues);
  }
  const onConfigParamChange = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("typeId", selected);
  };
  const onEntityNameChange = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("entityId", selected);
  };
  const renderSaveOrUpdateButton = () => {
    if (props.id > 0) {
      return (
        <Button type="submit" isLoading={isSubmitting} classNames="saveButton">
          <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
          <span>&nbsp;Update</span>
        </Button>
      );
    } else {
      return (
        <Button type="submit" isLoading={isSubmitting} classNames="saveButton">
          <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
          <span>&nbsp;Save</span>
        </Button>
      );
    }
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)} classNames="formBorder">
      <FormHeader
        classNames="formHeaderBorder"
        isLoading={isLoading}
        icon={<FaRegFileAlt />}
      >
        Menu
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" /> {""}
            Cancel
          </Button>
          {renderSaveOrUpdateButton()}
        </FormRow>
      </FormHeader>
      <FormContent classNames="formContentBackground">
        <Accordion>
          <AccordionSection
            className="accordion-section"
            title="Details"
            error={CommonUtil.sectionError(["keyName", "displayName"], errors)}
          >
            <FormRow classNames="border-bottom">
              <FormInput
                id="keyName"
                label="Name :"
                name="keyName"
                register={register}
                disabled={isLoading}
                placeholder="Enter your name"
                error={errors.keyName?.message}
                onKeyDown={CommonUtil.validateText}
                maxLength={40}
              ></FormInput>
              <FormInput
                name="displayName"
                label="Display Name :"
                register={register}
                disabled={isLoading}
                error={errors.displayName?.message}
                placeholder="Enter your display name"
                onKeyDown={CommonUtil.validateText}
                maxLength={40}
              ></FormInput>
            </FormRow>
            <FormRow classNames="border-bottom">
              <FormDropdown
                label="Menu Type :"
                value={formValues.typeId}
                classNames="hoverDropdown"
                error={errors.typeId?.message as string}
                placeholder="Please select type"
                onChange={onConfigParamChange}
                options={configParam}
              ></FormDropdown>
              <FormDropdown
                label="Entity :"
                apiUrl={getApiEndpoint(ApiGetEntitiesList)}
                valueKey="id"
                labelKey="entityName"
                classNames="hoverDropdown"
                value={formValues.entityId}
                placeholder="Please select entity"
                onChange={onEntityNameChange}
              ></FormDropdown>
            </FormRow>
            <FormRow classNames="border-bottom">
              <Label classNames="max-w-[6.2rem] min-w-[6rem] !p-[9px] whitespace-nowrap font-semibold">Upload Icon :</Label>
              <div className="w-full flex justify-between items-center">
                <div className="flex items-center">
                  <input
                    type="file"
                    ref={fileInputRef}
                    style={{ display: "none" }}
                    onChange={handleFileInputChange}
                  />
                  {formValues.menuIcon && (
                    <Image
                      src={`data:image/svg+xml+png+jpeg;base64,${formValues.menuIcon}`}
                      alt="Upload Icon"
                      className="w-[100px] h-[20px]"
                      width={35}
                      height={30}
                    />
                  )}
                </div>
                <div className="flex flex-col pt-1.5">
                  {formValues.menuIcon ? (
                    <div className="pr-[0.4rem]">
                      <FaTimes
                        onClick={() => onRemoveIcon(formValues)}
                        className="cursor-pointer flex items-center"
                      />
                    </div>
                  ) : (
                    <div className="pr-[0.4rem]">
                      <FaUpload
                        color="black"
                        onClick={() => fileInputRef.current?.click()}
                        className="cursor-pointer flex items-center"
                      />
                    </div>
                  )}
                </div>
              </div>
            </FormRow>
          </AccordionSection>
        </Accordion>
      </FormContent>
      <FormFooter classNames="formFooterBackground">
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" /> {""}
            Cancel
          </Button>
          {renderSaveOrUpdateButton()}
        </FormRow>
      </FormFooter>
    </Form>
  );
}

MenuForm.getLayout = DashboardLayout;