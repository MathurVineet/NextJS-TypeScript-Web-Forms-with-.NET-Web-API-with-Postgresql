/**
 * TableDrawerForm.tsx
 * This DrawerForm Component is used to display form like a Sidebar.
 */
import React, { useEffect, useState } from "react";
import * as yup from "yup";
import data from "./data.json";
import { useDrawer, useFetch, useModal } from "@/hooks";
import classnames from "classnames";
import CommonUtil from "@/utils/common";
import { yupResolver } from "@hookform/resolvers/yup";
import { FaEdit, FaPlus, FaRegFileAlt, FaTimes } from "react-icons/fa";
import DashboardLayout from "@/components/layout/dashboard";
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Resolver, SubmitHandler, useForm } from "react-hook-form";
import { faEllipsisV, faSave, faXmark } from "@fortawesome/free-solid-svg-icons";
import { INPUT_LENGTH, Regex, Validation_Messages } from "@/utils/validation";
import {
  Accordion,
  AccordionSection,
  Button,
  Form,
  FormRow,
  FormInput,
  FormDropdown,
  DatePicker,
  Table,
  TableBody,
  TableColumn,
  TableHead,
  DropdownOptionType,
  TableRow,
  FormContent,
  FormCheckbox,
  FormFooter,
  FormHeader,
  RadioOptionType,
  FormRadio,
  Popup,
} from "opexee-ui-library";
import type { MultiValue, OnChangeValue, SingleValue } from "react-select";
import { eCdCOM, eResultCode } from "@/utils/enum";
import {ApiGetCDcomList} from "@/utils/api.constant";
//for using local-deployed api's
import { BASEURLENGG } from "@/utils/api";

type DrawerProps = {
  id: number;
  isOpen?: any;
  onClose?: any;
};
type DrawerFormModel = {
  Id?: number;
  MbDsnCode: string;
  ChType: SingleValue<DropdownOptionType>;
  SerialPort: SingleValue<DropdownOptionType>;
  BaudRate: SingleValue<DropdownOptionType>;
  DataFlow: SingleValue<DropdownOptionType>;
  Parity: SingleValue<DropdownOptionType>;
  DataBit: SingleValue<DropdownOptionType>;
  StopBit: SingleValue<DropdownOptionType>;
  DelayBetPoll: string;
  Mode: SingleValue<DropdownOptionType>;
};
export default function TableDrawerForm(props: DrawerProps) {
  const { onCloseDrawer } = useDrawer();
  const { onShowModal } = useModal();
  const {post} = useFetch();//

  const initialValue: DrawerFormModel = {
    MbDsnCode: "",
    ChType: null,
    SerialPort: null,
    BaudRate: null,
    DataFlow: null,
    Parity: null,
    DataBit: null,
    StopBit: null,
    DelayBetPoll: "",
    Mode: null
  };
  
  // const validationSchema = yup.object({
  //   firstName: yup
  //     .string()
  //     .min(6, "First name must be at least 6 characters.")
  //     .max(20, "First name should not exceed 20 characters.")
  //     .required(Validation_Messages.required),
  //   lastName: yup
  //     .string()
  //     .min(6, "Last name must be at least 6 characters.")
  //     .max(20, "Last name should not exceed 20 characters.")
  //     .required(Validation_Messages.Required),
  //   email: yup
  //     .string()
  //     .min(6, Validation_Messages.Email_Min)
  //     .matches(Regex.EMAIL, Validation_Messages.Email_valid)
  //     .email(Validation_Messages.Email_valid)
  //     .required(Validation_Messages.Required),
  //   phone: yup
  //     .string()
  //     .min(10, Validation_Messages.Mobile_Number_Min)
  //     .max(10, Validation_Messages.Mobile_Number_Min)
  //     .matches(Regex.MOBILENO, Validation_Messages.Mobile_Number_Matches)
  //     .required(Validation_Messages.Required),
  //   hobbies: yup
  //     .array()
  //     .of(
  //       yup.object().shape({
  //         value: yup.number(),
  //         label: yup.string(),
  //       })
  //     )
  //     .min(1, "Please select at least one hobby.")
  //     .required(),
  //   country: yup
  //     .object({
  //       value: yup.number(),
  //       label: yup.string().min(1),
  //     })
  //     .test({
  //       test: (value) => value?.label !== "" && value.value != undefined,
  //       message: "Please select a country.",
  //     }),
  //   state: yup
  //     .object({
  //       value: yup.number(),
  //       label: yup.string().min(1),
  //     })
  //     .test({
  //       test: (value) => value?.label !== "" && value.value != undefined,
  //       message: "Please select a state.",
  //     }),
  //   city: yup
  //     .object({
  //       value: yup.number(),
  //       label: yup.string().min(1),
  //     })
  //     .test({
  //       test: (value) => value?.label !== "" && value.value != undefined,
  //       message: "Please select a city.",
  //     }),
  //   marksList: yup
  //     .array()
  //     .of(
  //       yup.object().shape({
  //         name: yup
  //           .string()
  //           .required("Please enter name.")
  //           .min(1, "Please enter name."),
  //         course: yup
  //           .object({
  //             value: yup.number(),
  //             label: yup.string().min(1),
  //           })
  //           .test({
  //             test: (value) => value?.label !== "" && value.value != undefined,
  //             message: "Please select a country.",
  //           }),
  //         s1: yup.number().min(1, Validation_Messages.required),
  //         s2: yup.number().min(1, Validation_Messages.required),
  //       })
  //     )
  //     .min(1, "Please add at least one record.")
  //     .required(),
  //   agree: yup
  //     .boolean()
  //     .oneOf(
  //       [true],
  //       "Please certify that the information is true and accurate by checking the box."
  //     )
  //     .required(),
  // });

  const {
    register,
    getValues,
    setValue,
    trigger,
    setFocus,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<DrawerFormModel>({
    mode: "all",
    defaultValues: initialValue,
    // resolver: yupResolver(
    //   validationSchema
    // ) as unknown as Resolver<DrawerFormModel>,
  });

  useEffect(() => {
    //setFocus("ChType");
    getComList(1);
    getComList(2);
    getComList(3);
    getComList(4);
    getComList(5);
    getComList(6);
    getComList(7);
    getComList(8);
  }, []);

  const formValues = getValues();

  const setFieldValue = (key: any, value: any) => {
    setValue(key, value, {
      shouldValidate: true,
      shouldTouch: true,
    });
  };


  // const onChTypeChangeOrCreate = async (
  //   selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  // ) => {
  //   setFieldValue("ChType", selected);
  // };
  const onChTypeChangeOrCreate = async () => {
  };

  const onComportChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("comport", selected);
  };

  const onBaudrateChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("baudrate", selected);
  };
  
  const onFlowChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("flow", selected);
  };

  const onParityChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("parity", selected);
  };

  const onDataChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("data", selected);
  };

  const onStopBitsChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("stopBits", selected);
  };

  const onModeChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue("mode", selected);
  };
 
  const onSubmit: SubmitHandler<DrawerFormModel> = async (
    values: DrawerFormModel
  ) => {
    try {
      const formData = {
        Id: values.Id,
        MbDsnCode: values.MbDsnCode,
        ChType: values.ChType,
        SerialPort: values.SerialPort,
        BaudRate: values.BaudRate,
        DataFlow: values.DataFlow,
        Parity: values.Parity,
        DataBit: values.DataBit,
        StopBit: values.StopBit,
        DelayBetPoll: values.DelayBetPoll,
        Mode: values.Mode,
      };
    } catch (error) {
      console.error("Error ! While submitting form - ", error);
    }
  };
  {/* for refrence */}
  // const  getComList = async ()=> {
  //   const payload = {
  //     "data": {
  //       "groupId": 1
  //     }
  //   }
  //   const response = await post(ApiGetCDcomList,payload);
  //   console.log('response',response);
  // }
  const [comportdropdownOptions, setcomportdropdownOptions] = useState([]);
  const [baudratedropdownOptions, setbaudratedropdownOptions] = useState([]);
  const [flowdropdownOptions, setcflowdropdownOptions] = useState([]);
  const [paritydropdownOptions, setparitydropdownOptions] = useState([]);
  const [datadropdownOptions, setdatadropdownOptions] = useState([]);
  const [stopBitsdropdownOptions, setstopBitsdropdownOptions] = useState([]);
  const [modedropdownOptions, setmodedropdownOptions] = useState([]);
  const [ChTypedropdownOptions, setChTypedropdownOptions] = useState([]);
  const getComList = async (id : number) => {
    try {
      const payload = {
        "data": {
         "groupId": id
      }
    };
      const response = await post(ApiGetCDcomList, payload);
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        const options = response.data.map((item: { name: string; shortCode: string; }) => ({
          label: item.name, // adjust this according to your response structure
          value: item.shortCode     // adjust this according to your response structure
        }));
        if(id==eCdCOM.COMPORT){
          setcomportdropdownOptions(options);
        }else if(id==2){
          setbaudratedropdownOptions(options);
        }
        else if(id==3){
          setcflowdropdownOptions(options);
        }
        else if(id==4){
          setparitydropdownOptions(options);
        }
        else if(id==5){
          setdatadropdownOptions(options);
        }
        else if(id==6){
          setstopBitsdropdownOptions(options);
        }
        else if(id==7){
          setmodedropdownOptions(options);
        }
        else if(id==8){
          setChTypedropdownOptions(options);
        }
      }else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };
  
  return (
    <Form onSubmit={handleSubmit(onSubmit)} classNames="formBorder">
      <FormHeader classNames="formHeaderBorder" icon={<FaRegFileAlt color="#54c1bd" />}>
        Communication Type
      </FormHeader>
      <FormContent classNames="formContentBackground">
          <FormRow classNames="border-bottom">           
              <FormDropdown
                name="ChType"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Communication Type :"
                value={formValues.ChType}
                options={ChTypedropdownOptions}
                error={errors.ChType?.message as string}
                placeholder="Select Communication Type"
                onCreateOption={onChTypeChangeOrCreate}
                onChange={onChTypeChangeOrCreate}
                //onBlur={() => {trigger("Comport")}}
              ></FormDropdown>
          </FormRow> 

          <FormRow classNames="border-bottom">
              <FormDropdown
                name="comport"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Comport :"
                value={formValues.SerialPort}
                options={comportdropdownOptions}
                error={errors.SerialPort?.message as string}
                placeholder="Select Comport"
                onCreateOption={onComportChangeOrCreate}
                // onChange={(event:any)=>{
                //        getComList()
                // }}
                //onBlur={() => trigger("baudrate");}
              ></FormDropdown>
              <FormDropdown
                name="baudrate"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Baudrate :"
                value={formValues.BaudRate}
                options={baudratedropdownOptions}
                error={errors.BaudRate?.message as string}
                placeholder="Select Baudrate"
                onCreateOption={onBaudrateChangeOrCreate}
                onChange={onBaudrateChangeOrCreate}
                //onBlur={() => {trigger("state");}}
              ></FormDropdown>
            </FormRow>

            <FormRow classNames="border-bottom">
              <FormDropdown
                name="flow"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Flow :"
                value={formValues.DataFlow}
                options={flowdropdownOptions}
                error={errors.DataFlow?.message as string}
                placeholder="Select Flow"
                onCreateOption={onFlowChangeOrCreate}
                onChange={onFlowChangeOrCreate}
                //onBlur={() => trigger("country")}
              ></FormDropdown>
              <FormDropdown
                name="parity"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Parity :"
                value={formValues.Parity}
                options={paritydropdownOptions}
                error={errors.Parity?.message as string}
                placeholder="Select Parity"
                onCreateOption={onParityChangeOrCreate}
                onChange={onParityChangeOrCreate}
                //onBlur={() => {trigger("state");}}
              ></FormDropdown>
            </FormRow>

            <FormRow classNames="border-bottom">
              <FormDropdown
                name="data"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Data :"
                value={formValues.DataBit}
                options={datadropdownOptions}
                error={errors.DataBit?.message as string}
                placeholder="Select Data"
                onCreateOption={onDataChangeOrCreate}
                onChange={onDataChangeOrCreate}
                //onBlur={() => trigger("country")}
              ></FormDropdown>
              <FormDropdown
                name="stopBits"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Stop Bits :"
                value={formValues.StopBit}
                options={stopBitsdropdownOptions}
                error={errors.StopBit?.message as string}
                placeholder="Select Stop Bits"
                onCreateOption={onStopBitsChangeOrCreate}
                onChange={onStopBitsChangeOrCreate}
                // onBlur={() => {
                //   trigger("state");
                // }}
              ></FormDropdown>
            </FormRow>

            <FormRow classNames="border-bottom">
              <FormInput
                label="Delay Bet Poll :"
                error={errors.DelayBetPoll?.message}
                name="delayBetPoll"
                id="delayBetPoll"
                register={register}
                placeholder="Enter Delay Bet Poll"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
              <FormDropdown
                name="mode"
                isCreatable={true}
                classNames="hoverDropdown"
                label="Mode :"
                value={formValues.Mode}
                options={modedropdownOptions}
                error={errors.Mode?.message as string}
                placeholder="Select Mode"
                onCreateOption={onModeChangeOrCreate}
                onChange={onModeChangeOrCreate}
                // onBlur={() => {
                //   trigger("state");
                // }}
              ></FormDropdown>
            </FormRow>

      </FormContent>
      <FormFooter classNames="formFooterBackground">
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" />
            <span>Cancel</span>
          </Button>
          <Button
            type="submit"
            classNames="saveButton"
            isLoading={isSubmitting}
          >
            <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
            <span>&nbsp;Save</span>
          </Button>
        </FormRow>
      </FormFooter>
    </Form>
  );
}

TableDrawerForm.getLayout = DashboardLayout;