/*
 * TableDrawerList.tsx
 * This component is created to view the list and remove the task.
 */
import React, { useState, useEffect } from "react";
import Utils from "@/utils";
import Image from "next/image";
import classnames from "classnames";
import DateUtils from "@/utils/date";
import { eResultCode } from "@/utils/enum";
import { useToast, useFetch, useModal, useDrawer } from "@/hooks";
import { TFilterModel } from "@/types/config";
import {
  Button,
  Search,
  PageHeader,
  Pagination,
  TableHead,
  Checkbox,
  Dropdown,
  DropdownOptionType,
  Popup,
  TableRow,
  Table,
  TableBody,
  TableColumn,
} from "opexee-ui-library";
import { useRouter } from "next/router";
import { DATE_FORMAT, filterDefaultValue } from "@/utils/constants";
import { ToastType } from "@/state/toast/slice";
import DashboardLayout from "@/components/layout/dashboard";
import { FaPlus, FaRegFileAlt, FaSearch } from "react-icons/fa";
import { FaEdit } from "react-icons/fa";
import { faChevronDown, faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import DrawerForm01 from "./form";
import { DrawerOpen } from "@/state/drawer/slice";
import { Task } from "@/types";
import { eRowStatus } from "@/utils/enum";
import { ApiGetProductList } from "@/utils/api.constant";

export default function TableDrawerList() {
  const router = useRouter();
  const { post } = useFetch();
  const { onShowToast } = useToast();
  const { onShowModal } = useModal();
  const { onShowDrawer } = useDrawer();
  const [tasks, setTasks] = useState<Array<Task>>([]);
  const [isLoading, setLoading] = useState(false);
  const [filterModel, setFilter] = useState<TFilterModel>({
    ...filterDefaultValue,
    ...router.query,
  });

  const updateFilter = (newFilter: Record<string, any> = {}) => {
    const updatedFilter = {
      ...filterModel,
      ...newFilter,
    };
    const componentName = router.query.component?.[0];
    router.push({
      pathname: "/dashboard/" + componentName,
      query: Utils.getQueryString({
        searchText: updatedFilter.searchText,
        currentPage: updatedFilter.currentPage,
        orderBy: updatedFilter.orderBy,
        orderType: updatedFilter.orderType,
        fromDate: updatedFilter.fromDate,
        toDate: updatedFilter.toDate,
      }),
    });
    setFilter(updatedFilter);
  };

  // useEffect(() => {
  //   onShowDrawer({
  //     dimmer: true,
  //     width: "50%",
  //     name: "Show Drawer Form",
  //     Component: DrawerForm01,
  //     position: DrawerOpen.right,
  //   });
  // }, []);
  
  useEffect(() => {
    if (router.isReady) {
      //fetchTasks({ ...filterModel, ...router.query });
    }
  }, [router.query]);

  const fetchTasks = async (filterModel: TFilterModel) => {
    try {
      const payload = {
        data: filterModel,
      };
      setLoading(true);
      const response = await post(ApiGetProductList, payload);
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        if (JSON.parse(localStorage.getItem("modeContinue") as string)) {
          response.data.unshift({ id: 0, rowStatus: eRowStatus.ADD});
        }
        setTasks(response.data);
        setFilter(response.filterModel);
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    } finally {
      setLoading(false);
    }
  };

  const onHandleEdit = (index: number) => {
    onShowDrawer({
      dimmer: true,
      width: "50%",
      name: "Show Drawer Form",
      Component: DrawerForm01,
      position: DrawerOpen.right,
    });
  };

  const onHandleAddEditTable = () => {
    onShowDrawer({
      dimmer: true,
      width: "50%",
      name: "Show Drawer Form",
      Component: DrawerForm01,
      position: DrawerOpen.right,
    });
  };

  const onHandleRemoveTask = async (id: number) => {
    onShowToast({
      type: ToastType.error,
      title: "error",
    });
  };

  const renderTask = (task: Task, index: number) => {
    return (
      <TableRow key={index}>
        <TableColumn classNames="w-[3%]" variant="centerAlign">
          <Checkbox
            name={`list.${index}.checkbox`}
            id={`list.${index}.checkbox`}
          />
        </TableColumn>
        <TableColumn classNames="w-[3%]" key={index} variant="centerAlign">
          {index + 1}
        </TableColumn>
        <TableColumn key={index} classNames="w-[10%]">
          <span>{task.details}</span>
        </TableColumn>
        <TableColumn classNames="w-[12%]">{task.area}</TableColumn>
        <TableColumn classNames="w-[10%]">{task.assignedTo}</TableColumn>
        <TableColumn classNames="w-[10%]" variant="centerAlign">
          {DateUtils.format(task.targetDate, DATE_FORMAT)}
        </TableColumn>
        <TableColumn classNames={`w-[10%]`} variant="centerAlign">
          {task.type}
        </TableColumn>
        <TableColumn classNames="w-[18%] !pr-2" variant="rightAlign">
          <div className="flex justify-end">
            <div
              className="pr-2 "
              onClick={() => {
                onHandleEdit(index);
              }}
            >
              <FaEdit color="#396077" size={15} className="cursor-pointer" />
            </div>
            <div
              onClick={() => {
                onHandleRemoveTask(task.id);
              }}
            >
              <img src="/assets/images/googleTrash.svg" alt="" />
            </div>
          </div>
        </TableColumn>
      </TableRow>
    );
  };

  const renderTasks = () => {
    return tasks.map(renderTask);
  };

  const onHandleAddEdit = () => {
  };

  const onHandleDelete = () => {
    onShowToast({
      type: ToastType.error,
      title: "error",
    });
  };

  const dropDownOption: DropdownOptionType[] = [
    { value: 1, label: "Edit Post" },
    { value: 2, label: "Remove Post" },
  ];

  return (
    <div className="pageBody">
      <PageHeader
        classNames="dropdown-max-w font-sans  tableForm  sm:text-xs md:text-xs"
        icon={<FaRegFileAlt />}
        title={"List without CRUD, Single line, Main"}
      >
        <Dropdown
          placeholder="Criteria One"
          classNames="!rounded-sm font-sans font-medium border-x border-y border-solid border-slate-300  pt-0.5  pb-0.5 border-black w-[10%]"
          options={dropDownOption}
        ></Dropdown>
        <Dropdown
          placeholder="Criteria Two"
          classNames="!rounded-sm font-sans font-medium border-x border-y border-solid border-slate-300  pt-0.5  pb-0.5 border-black w-[10%]"
          options={dropDownOption}
        ></Dropdown>
        <Dropdown
          placeholder="This week"
          classNames="!rounded-sm font-sans  font-medium border-x border-y border-solid border-slate-300 pt-0.5  pb-0.5 border-black w-[10%]"
          options={dropDownOption}
        ></Dropdown>
        <div className=" d-flex !text-xs border-slate-300  border-x border-y border-solid items-center px-1.5 py-1  rounded-sm">
          <Image
            src={"/assets/images/up_down_arrow 1.svg"}
            alt="icon"
            width={20}
            height={15}
          />
          <Image
            src={"/assets/images/down_arrow 1.svg"}
            alt="icon"
            width={30}
            height={15}
          />
          <Popup icon={faChevronDown} className="">
            <ul className={classnames("arrowPointer", "actionButtons")}>
              <li 
                className="actions" 
                onClick={onHandleAddEdit}>
                <FaEdit color="#396077" />
                Edit
              </li>
              <li
                className="actions"
                onClick={() => {
                  onShowModal({
                    content: "Are you sure you want to delete this record?",
                    showButton: true,
                    onSave: () => onHandleDelete(),
                  });
                }}
              >
                <img src="/assets/images/googleTrash.svg" alt="" />
                Delete
              </li>
            </ul>
          </Popup>
        </div>
        <div className="w-[75%] font-sans font-medium">
          <Search
            icon={<FaSearch />}
            classNames="py-1 !rounded-sm"
            iconClassNames="!text-xs !left-auto !right-4 !top-3.5"
            searchText={filterModel.searchText}
            onInputChange={(searchText: string) => updateFilter({ searchText })}
          />
        </div>
        <Image
          className="bg-primary px-1 py-1 rounded-sm"
          src={"/assets/images/filter 1.svg"}
          alt="icon"
          width={20}
          height={15}
        />
        <Image
          className="bg-primary px-1 py-1 rounded-sm"
          src={"/assets/images/maintenance_1 1.svg"}
          alt="icon"
          width={20}
          height={15}
        />
        <div className=" bg-primary  font-sans font-medium d-flex text-white items-center gap-2 px-2 py-1 text-xs rounded-sm">
          Action
          <Popup icon={faEllipsisV}>
            <ul className={classnames("arrowPointer", "actionButtons")}>
              <li className="actions" onClick={onHandleAddEdit}>
                <FaEdit color="#396077" />
                Edit
              </li>
              <li
                className="actions"
                onClick={() => {
                  onShowModal({
                    content: "Are you sure you want to delete this record?",
                    showButton: true,
                    onSave: () => onHandleDelete(),
                  });
                }}
              >
                <img src="/assets/images/googleTrash.svg" alt="" />
                Delete
              </li>
            </ul>
          </Popup>
        </div>
      </PageHeader>
      <div className="listContainer">
        <div className="tableContainer font-sans">
            <Table>
              <TableRow>
                <TableHead classNames="w-[3%]" variant="centerAlign">
                  <Checkbox name="menucheckbox" id="menucheckbox" />
                </TableHead>
                <TableHead
                  variant="centerAlign"
                  orderType={filterModel.orderType}
                  orderBy={filterModel.orderBy}
                  onSortKeyChange={(orderBy: string, orderType: string) => {
                    updateFilter({ orderBy, orderType });
                  }}
                  classNames="w-[3%]"
                >
                  Sr
                </TableHead>
                <TableHead
                  variant="centerAlign"
                  sortKey="details"
                  orderType={filterModel.orderType}
                  orderBy={filterModel.orderBy}
                  onSortKeyChange={(orderBy: string, orderType: string) => {
                    updateFilter({ orderBy, orderType });
                  }}
                  classNames="w-[10%]"
                >
                  Details
                </TableHead>
                <TableHead
                  variant="centerAlign"
                  sortKey="area"
                  orderType={filterModel.orderType}
                  orderBy={filterModel.orderBy}
                  onSortKeyChange={(orderBy: string, orderType: string) => {
                    updateFilter({ orderBy, orderType });
                  }}
                  classNames="w-[12%]"
                >
                  Areas/Projects
                </TableHead>
                <TableHead
                  variant="centerAlign"
                  sortKey="assignedTo"
                  orderType={filterModel.orderType}
                  orderBy={filterModel.orderBy}
                  onSortKeyChange={(orderBy: string, orderType: string) => {
                    updateFilter({ orderBy, orderType });
                  }}
                  classNames="w-[10%]"
                >
                  AssignedTo
                </TableHead>
                <TableHead
                  variant="centerAlign"
                  sortKey="targetdate"
                  orderType={filterModel.orderType}
                  orderBy={filterModel.orderBy}
                  onSortKeyChange={(orderBy: string, orderType: string) => {
                    updateFilter({ orderBy, orderType });
                  }}
                  classNames="w-[10%]"
                >
                  Target Date
                </TableHead>
                <TableHead
                  variant="centerAlign"
                  sortKey="type"
                  orderType={filterModel.orderType}
                  orderBy={filterModel.orderBy}
                  onSortKeyChange={(orderBy: string, orderType: string) => {
                    updateFilter({ orderBy, orderType });
                  }}
                  classNames="w-[10%]"
                >
                  Type
                </TableHead>
                <TableHead classNames="w-[18%] !pr-2" variant="rightAlign">
                  <Button
                    type="button"
                    classNames="!w-auto !bg-transparent border-none flex outline-none !p-0"
                    onClick={onHandleAddEditTable}
                  >
                    <FaPlus color="#396077" />
                  </Button>
                </TableHead>
              </TableRow>
              <TableBody>{renderTasks()}</TableBody>
            </Table>
        </div>
      </div>
      <div className="footer">
        <Pagination
          classNames=""
          pageSize={19}
          filterRowsCount={filterModel.filterRowsCount}
          totalRows={filterModel.totalRows}
          currentPage={filterModel.currentPage}
          onPageChange={(currentPage: number) => updateFilter({ currentPage })}
          onPageSizeChange={(pageSize: number) => updateFilter({ pageSize })}
          orderBy={filterModel.orderBy}
          orderType={filterModel.orderType}
        />
      </div>
    </div>
  );
}

TableDrawerList.getLayout = DashboardLayout;
