import React, { useEffect, useState } from "react";
import * as yup from "yup";
import data from "./data.json";
import { useDrawer, useModal, useFetch } from "@/hooks";
import classnames from "classnames";
import CommonUtil from "@/utils/common";
import { yupResolver } from "@hookform/resolvers/yup";
import { FaEdit, FaPlus, FaRegFileAlt, FaTimes } from "react-icons/fa";
import DashboardLayout from "@/components/layout/dashboard";
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Resolver, SubmitHandler, useForm } from "react-hook-form";
import {
  faEllipsisV,
  faSave,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import { INPUT_LENGTH, Regex, Validation_Messages } from "@/utils/validation";
import {
  Accordion,
  AccordionSection,
  Button,
  Form,
  FormRow,
  FormInput,
  FormDropdown,
  DatePicker,
  Table,
  TableBody,
  TableColumn,
  TableHead,
  DropdownOptionType,
  TableRow,
  FormContent,
  FormCheckbox,
  FormFooter,
  FormHeader,
  RadioOptionType,
  FormRadio,
  Popup,
} from "opexee-ui-library";
import type { MultiValue, OnChangeValue, SingleValue } from "react-select";
import { eTagDef, eResultCode } from "@/utils/enum";
import {
  ApiGetTagDefList,
  ApiGetTagDefById,
  ApiAddEditTagDef,
} from "@/utils/api.constant";

type DrawerProps = {
  id: number;
  isOpen?: any;
  onClose?: any;
};

type DrawerFormModel = {
  id: number;
  name: string;
  description: string;
  locTypeCode: string;
  convDataType: string;
  startAddress: number;
  noOfRegister: number;
  enableExp: number;
  expression?: string;
  enableScaling: number;
  scalingType?: string;
  rawMin?: number;
  rawMax?: number;
  scaleMin?: number;
  scaleMax?: number;
  active: number;
  readOnly: number;
};

export default function TableDrawerForm(props: DrawerProps) {
  const { onCloseDrawer } = useDrawer();
  const { onShowModal } = useModal();
  const { post } = useFetch();
  const [locationTypedropdownOptions, setlocationTypedropdownOptions] =
    useState([]);
  const [dataTypedropdownOptions, setdataTypedropdownOptions] = useState([]);
  const [scalingTypedropdownOptions, setscalingTypedropdownOptions] = useState(
    []
  );

  const validateExpression: any = (value: number) => {
    if (formValues.enableExp == 1) {
      return value != undefined && value != null;
    }
    return true;
  };
  const validateEnableExp: any = () => {
    if (formValues.enableExp == 1) {
      return formValues.enableExp;
    }
    return true;
  };
  const validateScalingType: any = (value: string) => {
    if (formValues.enableScaling == 1) {
      return value != undefined && value != null && value != "";
    }
    return true;
  };
  const validateScalingParam: any = (value: number) => {
    if (formValues.enableScaling == 1) {
      return value != undefined && value != null && value > 0;
    }
    return true;
  };
  const validateEnableScaling: any = () => {
    if (formValues.enableScaling == 1) {
      return formValues.enableScaling;
    }
    return true;
  };

  const initialValue: DrawerFormModel = {
    id: 0,
    name: "",
    description: "",
    locTypeCode: "",
    convDataType: "",
    startAddress: 0,
    noOfRegister: 0,
    enableExp: 0,
    enableScaling: 0,
    active: 0,
    readOnly: 0,
  };

  const validationSchema = yup.object({
    //return true when you don't want to throw an error.
    name: yup
      .string()
      .test(
        "is-required-if",
        "Please enter a name",
        (value) => value !== undefined && value !== null && value !== ""
      ),

    description: yup
      .string()
      .test(
        "is-required-if",
        "Please enter a description",
        (value) => value !== undefined && value !== null && value !== ""
      ),

    locTypeCode: yup
      .string()
      .test(
        "is-required-if",
        "Please select a location type",
        (value) => value !== undefined && value !== null && value !== ""
      ),

    convDataType: yup
      .string()
      .test(
        "is-required-if",
        "Please select a convDataType",
        (value) => value !== undefined && value !== null && value !== ""
      ),

    startAddress: yup
      .number()
      .test(
        "is-required-if",
        "Please enter a start address",
        (value) => value !== undefined && value !== null && value > 0
      ),

    noOfRegister: yup
      .number()
      .test(
        "is-required-if",
        "Please enter the number of registers",
        (value) => value != undefined && value != null && value > 0
      ),

    enableExp: yup
      .number()
      .test(
        "is-required-if",
        "Please specify if enableExp is true or false",
        validateEnableExp
      ),

    expression: yup
      .mixed()
      .test(
        "is-required-if",
        "Please specify if enableExp is true or false",
        validateExpression
      ),

    enableScaling: yup
      .number()
      .test(
        "is-required-if",
        "Please specify if enableScaling is true or false",
        validateEnableScaling
      ),

    scalingType: yup
      .mixed()
      .test(
        "is-required-if",
        "Please select a scaling type",
        validateScalingType
      ),
    rawMin: yup
      .mixed()
      .test("is-required-if", "Please enter a rawMin", validateScalingParam),

    rawMax: yup
      .mixed()
      .test("is-required-if", "Please enter a rawMax", validateScalingParam),

    scaleMin: yup
      .mixed()
      .test("is-required-if", "Please enter a scaleMin", validateScalingParam),

    scaleMax: yup
      .mixed()
      .test("is-required-if", "Please enter a scaleMax", validateScalingParam),

    active: yup
      .number()
      .test({
        test: (value: any) => value != undefined && value != null,
        message: "Please specify if active is true or false",
      })
      .notRequired(),

    readOnly: yup
      .number()
      .test({
        test: (value: any) => value != undefined && value != null,
        message: "Please specify if readOnly is true or false",
      })
      .notRequired(),
  });

  const {
    register,
    getValues,
    setValue,
    trigger,
    setFocus,
    handleSubmit,
    clearErrors,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<DrawerFormModel>({
    mode: "all",
    defaultValues: initialValue,
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<DrawerFormModel>,
  });

  useEffect(() => {
    setFocus("name");
    getComList(eTagDef.LocationType);
    getComList(eTagDef.DataType);
    getComList(eTagDef.ScalingType);
    getComListByID(4);
  }, []);

  const getComList = async (id: eTagDef) => {
    try {
      const payload = {
        data: {
          groupId: id,
        },
      };
      const response = await post(ApiGetTagDefList, payload);
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        const options = response.data.map(
          (item: { name: string; shortCode: string }) => ({
            label: item.name,
            value: item.shortCode,
          })
        );
        switch (id) {
          case eTagDef.LocationType:
            setlocationTypedropdownOptions(options);
            break;
          case eTagDef.DataType:
            setdataTypedropdownOptions(options);
            break;
          case eTagDef.ScalingType:
            setscalingTypedropdownOptions(options);
            break;
          default:
            console.error("Unknown id:", id);
        }
        return options;
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };

  const getComListByID = async (id: number) => {
    try {
      const payload = {
        data: {
          id: id,
        },
      };
      const response = await post(ApiGetTagDefById, payload);
      const { data } = response;
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        console.log("API response:", response);
        console.log("Response data:", data[0]);
        reset(data[0]);
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };

  const formValues = getValues();

  const setFieldValue = (key: any, value: any) => {
    setValue(key, value, {
      shouldValidate: true,
      shouldTouch: true,
    });
  };

  const onlocationTypeChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue(
      "locTypeCode",
      (selected as DropdownOptionType)?.value as string
    );
  };

  const ondataTypeChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue(
      "convDataType",
      (selected as DropdownOptionType)?.value as string
    );
  };

  const onscalingTypeChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue(
      "scalingType",
      (selected as DropdownOptionType)?.value as string
    );
  };

  const onSubmit: SubmitHandler<DrawerFormModel> = async (
    values: DrawerFormModel
  ) => {
    try {
      const formData = {
        data: {
          //name: values.name,
          //description: values.description,
          id: values.id,
          locTypeCode: values.locTypeCode,
          convDataType: values.convDataType,
          startAddress: values.startAddress,
          noOfRegister: values.noOfRegister,
          enableExp: values.enableExp,
          expression: values.expression,
          enableScaling: values.enableScaling,
          scalingType: values.scalingType,
          rawMin: values.rawMin,
          rawMax: values.rawMax,
          scaleMin: values.scaleMin,
          scaleMax: values.scaleMax,
          //active: values.active,
          readOnly: values.readOnly,
        },
      };
      console.log("Send data:", formData);
      const response = await post(ApiAddEditTagDef, formData);
      console.log("response", response);
    } catch (error) {
      console.error("Error ! While submitting form - ", error);
    }
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)} classNames="formBorder">
      <FormHeader
        classNames="formHeaderBorder"
        icon={<FaRegFileAlt color="#54c1bd" />}
      >
        Tag Definition
      </FormHeader>

      <FormContent classNames="formContentBackground">
        <FormRow classNames="border-bottom">
          <FormInput
            label="Name"
            error={errors.name?.message}
            name="name"
            id="name"
            register={register}
            placeholder="Enter Tag Name"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </FormRow>

        <FormRow classNames="border-bottom">
          <FormInput
            label="Description"
            error={errors.description?.message}
            name="description"
            id="description"
            register={register}
            placeholder="Enter Tag Description"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </FormRow>

        <FormRow classNames="border-bottom">
          <FormDropdown
            name="locTypeCode"
            isCreatable={false}
            classNames="hoverDropdown"
            label="Location Type"
            value={{
              value: formValues.locTypeCode,
              label: "",
            }}
            options={locationTypedropdownOptions}
            error={errors.locTypeCode?.message as string}
            placeholder="Select Location Type"
            //onCreateOption={onlocationTypeChangeOrCreate}
            onChange={onlocationTypeChangeOrCreate}
            // onBlur={() => trigger("locTypeCode")}
          ></FormDropdown>
          <FormDropdown
            name="convDataType"
            isCreatable={false}
            classNames="hoverDropdown"
            label="Data Type"
            value={{
              value: formValues.convDataType,
              label: "",
            }}
            options={dataTypedropdownOptions}
            error={errors.convDataType?.message as string}
            placeholder="Select Data Type"
            //onCreateOption={ondataTypeChangeOrCreate}
            onChange={ondataTypeChangeOrCreate}
            // onBlur={() => trigger("convDataType")}
          ></FormDropdown>
        </FormRow>

        <FormRow classNames="border-bottom">
          <FormInput
            label="Start Address"
            error={errors.startAddress?.message}
            name="startAddress"
            id="startAddress"
            register={register}
            placeholder="Enter Start Address"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyDown={CommonUtil.validateNumber}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
          <FormInput
            label="No of Register :"
            error={errors.noOfRegister?.message}
            name="noOfRegister"
            register={register}
            placeholder="Enter No of Register"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyDown={CommonUtil.validateNumber}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </FormRow>

        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={"Apply Formula"}
            error={errors.enableExp?.message}
            checked={formValues.enableExp == 1}
            name="enableExp"
            register={register}
            onChange={() => {
              if (formValues.enableExp == 1) {
                setFieldValue("enableExp", 0);
              } else {
                setFieldValue("enableExp", 1);
              }
              clearErrors(["expression"]);
            }}
          ></FormCheckbox>
        </FormRow>

        {formValues.enableExp ? (
          <>
            <FormRow classNames="border-bottom">
              <FormInput
                label="expression"
                error={errors.expression?.message}
                name="expression"
                register={register}
                placeholder="Enter Formula"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
            </FormRow>
          </>
        ) : (
          <></>
        )}

        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={"Apply Scaling"}
            error={errors.enableScaling?.message}
            checked={formValues.enableScaling == 1}
            name="enableScaling"
            register={register}
            onChange={() => {
              if (formValues.enableScaling == 1) {
                setFieldValue("enableScaling", 0);
              } else {
                setFieldValue("enableScaling", 1);
              }
              clearErrors([
                "scalingType",
                "rawMin",
                "rawMax",
                "scaleMin",
                "scaleMax",
              ]);
            }}
          ></FormCheckbox>
        </FormRow>

        {formValues.enableScaling ? (
          <>
            <FormRow classNames="formGender border-bottom">
              <FormDropdown
                name="scalingType"
                isCreatable={false}
                classNames="hoverDropdown"
                label="Scaling Type"
                value={{
                  value: formValues.scalingType,
                  label: "",
                }}
                options={scalingTypedropdownOptions}
                error={errors.scalingType?.message as string}
                placeholder="Select Data Type"
                //onCreateOption={onscalingTypeChangeOrCreate}
                onChange={onscalingTypeChangeOrCreate}
                //onBlur={() => trigger("scalingType")}
              ></FormDropdown>
            </FormRow>

            <FormRow classNames="border-bottom">
              <FormInput
                label="Raw Min"
                error={errors.rawMin?.message}
                name="rawMin"
                id="rawMin"
                register={register}
                placeholder="Enter Raw Min"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
              <FormInput
                label="Raw Max"
                error={errors.rawMax?.message}
                name="rawMax"
                id="rawMax"
                register={register}
                placeholder="Enter Raw Max"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
            </FormRow>

            <FormRow classNames="border-bottom">
              <FormInput
                label="Scale Min"
                error={errors.scaleMin?.message}
                name="scaleMin"
                id="scaleMin"
                register={register}
                placeholder="Enter Scale Min"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
              <FormInput
                label="Scale Max"
                error={errors.scaleMax?.message}
                name="scaleMax"
                id="scaleMax"
                register={register}
                placeholder="Enter Scale Max"
                maxLength={INPUT_LENGTH.NAME_LENGTH}
                onKeyPress={CommonUtil.validateEnterKey}
              ></FormInput>
            </FormRow>
          </>
        ) : (
          <></>
        )}

        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={"Active"}
            error={errors.active?.message}
            checked={formValues.active == 1}
            name="active"
            register={register}
            onChange={() => {
              if (formValues.active == 1) {
                setFieldValue("active", 0);
              } else {
                setFieldValue("active", 1);
              }
            }}
          ></FormCheckbox>
        </FormRow>

        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={"Read Only"}
            error={errors.readOnly?.message}
            checked={formValues.readOnly == 1}
            name="readOnly"
            register={register}
            onChange={() => {
              setFieldValue("readOnly", !formValues.readOnly);
              if (formValues.readOnly == 1) {
                setFieldValue("readOnly", 0);
              } else {
                setFieldValue("readOnly", 1);
              }
            }}
          ></FormCheckbox>
        </FormRow>
      </FormContent>

      <FormFooter classNames="formFooterBackground">
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" />
            <span>Cancel</span>
          </Button>
          <Button
            type="submit"
            onClick={() => console.log(errors, "errors")}
            classNames="saveButton"
            isLoading={isSubmitting}
          >
            <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
            <span>&nbsp;Save</span>
          </Button>
        </FormRow>
      </FormFooter>
    </Form>
  );
}

TableDrawerForm.getLayout = DashboardLayout;
