import React, { useEffect, useState } from "react";
import * as yup from "yup";
import data from "./data.json";
import { useDrawer, useModal, useFetch } from "@/hooks";
import classnames from "classnames";
import CommonUtil from "@/utils/common";
import { yupResolver } from "@hookform/resolvers/yup";
import { FaEdit, FaPlus, FaRegFileAlt, FaTimes } from "react-icons/fa";
import DashboardLayout from "@/components/layout/dashboard";
import { IconProp } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Resolver, SubmitHandler, useForm } from "react-hook-form";
import {
  faEllipsisV,
  faSave,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import { INPUT_LENGTH, Regex, Validation_Messages } from "@/utils/validation";
import {
  Accordion,
  AccordionSection,
  Button,
  Form,
  FormRow,
  FormInput,
  FormDropdown,
  DatePicker,
  Table,
  TableBody,
  TableColumn,
  TableHead,
  DropdownOptionType,
  TableRow,
  FormContent,
  FormCheckbox,
  FormFooter,
  FormHeader,
  RadioOptionType,
  FormRadio,
  Popup,
} from "opexee-ui-library";
import type { MultiValue, OnChangeValue, SingleValue } from "react-select";
import { eDeviceDef, eResultCode } from "@/utils/enum";
import {
  ApiGetDeviceDefList,
  ApiGetDeviceDefById,
  ApiAddEditDeviceDef,
} from "@/utils/api.constant";
import { log } from "console";

type DrawerProps = {
  id: number;
  isOpen?: any;
  onClose?: any;
};

type DrawerFormModel = {
  name?: string;
  template?: string;
  description?: string;

  id?: number;
  orgId: number;
  mbDsnCode: string;
  //mb_dsn_device
  slaveAddress: number;
  timeout: number;
  wordswap: number;
  enableSimulation: number;
  // mb_dsn_device_blocks
  deviceBlockList: Array<deviceBlock>;
  // startAddress: number;
  // endAddress: number;
  // locTypeCode: string;
  // scanRate: number;
  //deviceBlockid:number;
  //deviceBlockDescription:string;

  active: number;
};

type deviceBlock = {
  id: number;
  orgId?: number;
  mbDsnCode?: string;
  startAddress: number;
  endAddress: number;
  locTypeCode?: string;
  scanRate: number;
  devBlockDes?: string;
};

export default function TableDrawerForm(props: DrawerProps) {
  const { onCloseDrawer } = useDrawer();
  const { onShowModal } = useModal();
  const { post } = useFetch();
  const [templatedropdownOptions, settemplatedropdownOptions] = useState([]);
  const [locTypeCodedropdownOptions, setlocTypeCodedropdownOptions] = useState(
    []
  );

  const initialValue: DrawerFormModel = {
    name: "",
    template: "",
    description: "",
    id: 0,
    orgId: 0,
    mbDsnCode: "",
    //mb_dsn_device
    slaveAddress: 0,
    timeout: 0,
    wordswap: 0,
    enableSimulation: 0,
    // mb_dsn_device_blocks
    deviceBlockList: [],
    active: 0,
  };

  // Reusable validation functions
  const isRequiredString = (message: string) =>
    yup
      .string()
      .test(
        "is-required-if",
        message,
        (value) => value !== undefined && value !== null && value !== ""
      );
  const isRequiredNumber = (message: any) =>
    yup
      .number()
      .test(
        "is-required-if",
        message,
        (value) => value !== undefined && value !== null && value > 0
      );

  const validationSchema = yup.object({
    //name: isRequiredString("Please enter a name"),
    //template: isRequiredString("Please enter a template"),
    //description: isRequiredString("Please enter a description"),

    id: yup.number().notRequired(), // Optional field
    orgId: isRequiredNumber("Please enter an organization ID"),
    mbDsnCode: isRequiredString("Please enter a MB DSN code"),

    // mb_dsn_device
    slaveAddress: isRequiredNumber("Please enter a slave address"),
    timeout: isRequiredNumber("Please enter a timeout"),

    //wordswap: isRequiredNumber("Please enter a word swap").notRequired(),
    //enableSimulation: isRequiredNumber("Please specify if simulation is enabled").notRequired(),

    // mb_dsn_device_blocks
    //deviceBlockid: isRequiredNumber("Please enter a device block ID"),
    // startAddress: isRequiredNumber("Please enter a start address"),
    // endAddress: isRequiredNumber("Please enter an end address"),
    // locTypeCode: isRequiredString("Please enter a location type code"),
    // scanRate: isRequiredNumber("Please enter a scan rate"),
    //deviceBlockDescription: isRequiredString("Please enter a device block description"),

    deviceBlockList: yup
      .array()
      .of(
        yup.object().shape({
          id: isRequiredNumber("Please enter a device block ID").notRequired(), // Optional field
          orgId: isRequiredNumber(
            "Please enter an organization ID"
          ).notRequired(),
          mbDsnCode: isRequiredString(
            "Please enter a MB DSN code"
          ).notRequired(),
          startAddress: isRequiredNumber("Please enter a start address"),
          endAddress: isRequiredNumber("Please enter an end address"),
          locTypeCode: isRequiredString("Please enter a location type code"),
          scanRate: isRequiredNumber("Please enter a scan rate"),
          //deviceBlockDescription: isRequiredString("Please enter a device block description"),
        })
      )
      .required(),

    // active: yup.number().test("is-required-if", "Please specify if active is true or false", (value) => value !== undefined && value !== null).notRequired(),
  });

  const {
    register,
    getValues,
    setValue,
    trigger,
    setFocus,
    handleSubmit,
    clearErrors,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<DrawerFormModel>({
    mode: "all",
    defaultValues: initialValue,
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<DrawerFormModel>,
  });

  useEffect(() => {
    setFocus("timeout");
  }, []);

  const GetDeviceDefList = async (id: eDeviceDef) => {
    try {
      const payload = {
        data: {
          groupId: id,
        },
      };
      const response = await post(ApiGetDeviceDefList, payload);
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        const options = response.data.map(
          (item: { name: string; shortCode: string }) => ({
            label: item.name,
            value: item.shortCode,
          })
        );
        switch (id) {
          case eDeviceDef.Template:
            settemplatedropdownOptions(options);
            break;
          case eDeviceDef.LocationType:
            setlocTypeCodedropdownOptions(options);
            break;
          default:
            console.error("Unknown id:", id);
        }
        return options;
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };

  const GetDeviceDefById = async (id: number) => {
    try {
      const payload = {
        data: {
          id: id,
        },
      };
      const response = await post(ApiGetDeviceDefById, payload);
      const { data } = response;
      if (response.dataResponse.returnCode === eResultCode.SUCCESS) {
        console.log("API response:", response);
        console.log("Response data:", data[0]);
        reset(data[0]);
      } else {
        console.error("API response does not contain data:", response);
      }
    } catch (error) {
      console.error("Encountered Error! While fetching tasks- ", error);
    }
  };

  const ontemplateTypeChangeOrCreate = async (
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    setFieldValue(
      "template",
      (selected as DropdownOptionType)?.value as string
    );
  };

  const formValues = getValues();

  const setFieldValue = (key: any, value: any) => {
    setValue(key, value, {
      shouldValidate: true,
      shouldTouch: true,
    });
  };

  const addDeviceBlock = () => {
    const newItem = {
      id: 0,
      orgId: 0,
      mbDsnCode: "",
      startAddress: 0,
      endAddress: 0,
      locTypeCode: "",
      scanRate: 0,
      devBlockDes: "",
    };
    const listdata = formValues?.deviceBlockList
      ? formValues.deviceBlockList
      : [];
    listdata.unshift(newItem);
    console.log("listdata", listdata);

    setFieldValue("deviceBlockList", listdata);
  };

  const removeDeviceBlock = (index: number) => {
    const updatedList = formValues?.deviceBlockList
      ? formValues.deviceBlockList
      : [];
    updatedList.splice(index, 1);
    setFieldValue("deviceBlockList", updatedList);
  };

  const handleStartAddressChange = (index: number, value: number) => {
    const newList = formValues?.deviceBlockList
      ? formValues.deviceBlockList
      : [];
    newList[index].startAddress = value;
    setFieldValue("deviceBlockList", newList);
  };
  const handleEndAddressChange = (index: number, value: number) => {
    const newList = formValues?.deviceBlockList
      ? formValues.deviceBlockList
      : [];
    newList[index].endAddress = value;
    setFieldValue("deviceBlockList", newList);
  };
  const handleLocTypeCodeChange = (
    index: number,
    selected: SingleValue<DropdownOptionType> | MultiValue<DropdownOptionType>
  ) => {
    const newList = formValues.deviceBlockList
      ? formValues.deviceBlockList
      : [];
    newList[index].locTypeCode = (selected as DropdownOptionType)
      ?.value as string;
    setFieldValue("deviceBlockList", newList);
  };
  const handleScanRateChange = (index: number, value: number) => {
    const newList = formValues?.deviceBlockList
      ? formValues.deviceBlockList
      : [];
    newList[index].scanRate = value;
    setFieldValue("deviceBlockList", newList);
  };
  const handledevBlockDesChange = (index: number, value: string) => {
    const newList = formValues?.deviceBlockList
      ? formValues.deviceBlockList
      : [];
    newList[index].devBlockDes = value;
    setFieldValue("deviceBlockList", newList);
  };

  const renderDeviceBlocks = () => {
    return formValues?.deviceBlockList?.map((item, index) => (
      <TableRow key={index}>
        <TableColumn classNames="w-[5%]" key={index} variant="centerAlign">
          {index + 1}
        </TableColumn>

        <TableColumn variant="centerAlign" classNames="!text-left !p-0">
          <FormInput
            error={errors.deviceBlockList?.[index]?.startAddress?.message}
            name={item.startAddress.toString() || ""}
            value={item?.startAddress}
            placeholder="Enter Start Address"
            onChange={(data: any) =>
              handleStartAddressChange(index, data.target.value)
            }
            onKeyDown={CommonUtil.validateNumber}
          ></FormInput>
        </TableColumn>

        <TableColumn variant="centerAlign" classNames="!text-left !p-0">
          <FormInput
            error={errors.deviceBlockList?.[index]?.endAddress?.message}
            name={item.endAddress.toString() || ""}
            value={item.endAddress}
            placeholder="Enter End Address"
            onChange={(data: any) =>
              handleEndAddressChange(index, data.target.value)
            }
            onKeyDown={CommonUtil.validateNumber}
          ></FormInput>
        </TableColumn>

        <TableColumn
          variant="centerAlign"
          classNames="dropdownFormDropdown !text-left !p-0"
        >
          <FormDropdown
            // value={{
            //   value: item?.locTypeCode,
            //   label: "",
            // }}
            // value={item.locTypeCode}
            options={locTypeCodedropdownOptions}
            error={
              errors.deviceBlockList?.[index]?.locTypeCode?.message as string
            }
            placeholder="Location Type"
            onChange={(selected: any) => {
              handleLocTypeCodeChange(index, selected);
            }}
          ></FormDropdown>
        </TableColumn>

        <TableColumn variant="centerAlign" classNames="!text-left !p-0">
          <FormInput
            error={errors.deviceBlockList?.[index]?.scanRate?.message}
            name={item?.scanRate.toString() || ""}
            value={item?.scanRate}
            placeholder="Enter Scan Rate"
            onChange={(data: any) =>
              handleScanRateChange(index, data.target.value)
            }
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyDown={CommonUtil.validateNumber}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </TableColumn>

        <TableColumn classNames="!text-left !p-0">
          <FormInput
            error={errors.deviceBlockList?.[index]?.devBlockDes?.message}
            placeholder="Enter Description"
            name={item?.devBlockDes?.toString() || ""}
            value={item?.devBlockDes}
            onChange={(data: any) =>
              handledevBlockDesChange(index, data.target.value)
            }
            maxLength={INPUT_LENGTH.MARKS_LENGTH}
            onKeyDown={CommonUtil.validateText}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </TableColumn>

        <TableColumn variant="centerAlign" classNames="">
          <FaTimes
            color="rgb(128 133 137)"
            onClick={() => removeDeviceBlock(index)}
            title="Delete"
            className="cursorPointer"
          />
        </TableColumn>
      </TableRow>
    ));
  };

  const onSubmit: SubmitHandler<DrawerFormModel> = async (
    values: DrawerFormModel
  ) => {
    try {
      const formData = {
        id: values.id,
        orgId: values.orgId,
        mbDsnCode: values.mbDsnCode,

        name: values.name,
        template: values.template,
        description: values.description,
        //mb_dsn_device
        slaveAddress: values.slaveAddress,
        timeout: values.timeout,
        wordswap: values.wordswap,
        enableSimulation: values.enableSimulation,

        // mb_dsn_device_blocks
        // startAddress: values.startAddress,
        // endAddress: formValues.endAddress,
        // locTypeCode: values.locTypeCode,
        // scanRate: values.scanRate,
        deviceBlockList: values.deviceBlockList,

        active: values.active,
      };
      console.log("Send data:", formData);
      const response = await post(ApiAddEditDeviceDef, formData);
      console.log("response", response);
    } catch (error) {
      console.error("Error ! While submitting form - ", error);
    }
  };

  return (
    <Form onSubmit={handleSubmit(onSubmit)} classNames="formBorder">
      <FormHeader
        classNames="formHeaderBorder"
        icon={<FaRegFileAlt color="#54c1bd" />}
      >
        Device Definition
      </FormHeader>

      <FormContent classNames="formContentBackground">
        <FormRow classNames="border-bottom">
          <FormInput
            label="Name :"
            error={errors.name?.message}
            name="name"
            id="name"
            register={register}
            placeholder="Enter Device Name"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
          <FormDropdown
            name="template"
            isCreatable={false}
            classNames="hoverDropdown"
            label="Template :"
            value={{
              value: formValues.template,
              label: "",
            }}
            options={templatedropdownOptions}
            error={errors.template?.message as string}
            isMulti={false}
            placeholder="Select Template"
            onChange={ontemplateTypeChangeOrCreate}
            // onBlur={() => {trigger("template");}}
          ></FormDropdown>
        </FormRow>
        <FormRow classNames="border-bottom">
          <FormInput
            label="Slave Id :"
            error={errors.slaveAddress?.message}
            name="slaveAddress"
            register={register}
            placeholder="Enter Slave Address"
            maxLength={INPUT_LENGTH.EMAIL_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
          <FormInput
            label="Timeout(ms) :"
            error={errors.timeout?.message}
            name="timeout"
            register={register}
            placeholder="Enter Timeout(ms)"
            maxLength={INPUT_LENGTH.MOBILE_LENGTH}
            onKeyDown={CommonUtil.validateNumber}
          ></FormInput>
        </FormRow>
        <FormRow classNames="border-bottom">
          <FormInput
            label="Description :"
            error={errors.description?.message}
            name="description"
            id="description"
            register={register}
            placeholder="Description"
            maxLength={INPUT_LENGTH.NAME_LENGTH}
            onKeyPress={CommonUtil.validateEnterKey}
          ></FormInput>
        </FormRow>

        <div className="formTable">
          <Table classNames="editableTable">
            <TableRow>
              <TableHead
                variant="centerAlign"
                width="5%"
                classNames={classnames("editableTableHead", "!pl-[10px]")}
              >
                Sr
              </TableHead>
              <TableHead
                width="17%"
                classNames={classnames("editableTableHead", "!pl-[10px]")}
              >
                Start Address
              </TableHead>
              <TableHead
                width="17%"
                classNames={classnames("editableTableHead", "!pl-[10px]")}
              >
                End Address
              </TableHead>
              <TableHead
                width="15%"
                classNames={classnames("editableTableHead", "!pl-[10px]")}
              >
                Location Type
              </TableHead>
              <TableHead
                width="13%"
                classNames={classnames("editableTableHead", "!pl-[10px]")}
              >
                Scan Rate(ms)
              </TableHead>
              <TableHead
                width="17%"
                classNames={classnames("editableTableHead", "!pl-[8px]")}
              >
                Description
              </TableHead>
              <TableHead
                variant="rightAlign"
                width="5%"
                classNames={classnames("editableTableHead ")}
              >
                <Button
                  data-title={
                    errors.deviceBlockList?.message
                      ? errors.deviceBlockList?.message
                      : "Add"
                  }
                  classNames={classnames(
                    {
                      ["disabled-button"]: !errors.deviceBlockList?.message,
                    },
                    "!bg-white !p-0"
                  )}
                  onClick={() => addDeviceBlock()}
                >
                  <FaPlus
                    color={
                      errors.deviceBlockList?.message ? "#ec4a3d" : "#396077"
                    }
                  />
                </Button>
              </TableHead>
            </TableRow>
            <TableBody>{renderDeviceBlocks()}</TableBody>
          </Table>
        </div>

        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={"Word Swap"}
            error={errors.wordswap?.message}
            checked={formValues.wordswap == 1}
            name="wordswap"
            register={register}
            onChange={() => {
              if (formValues.wordswap == 1) {
                setFieldValue("wordswap", 0);
              } else {
                setFieldValue("wordswap", 1);
              }
            }}
          ></FormCheckbox>
        </FormRow>
        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={"Simulate"}
            error={errors.enableSimulation?.message}
            checked={formValues.enableSimulation == 1}
            name="simulate"
            register={register}
            onChange={() => {
              if (formValues.enableSimulation == 1) {
                setFieldValue("enableSimulation", 0);
              } else {
                setFieldValue("enableSimulation", 1);
              }
            }}
          ></FormCheckbox>
        </FormRow>
        <FormRow classNames="!border-none !relative">
          <FormCheckbox
            label={"Active"}
            error={errors.active?.message}
            checked={formValues.active == 1}
            name="active"
            register={register}
            onChange={() => {
              if (formValues.active == 1) {
                setFieldValue("active", 0);
              } else {
                setFieldValue("active", 1);
              }
            }}
          ></FormCheckbox>
        </FormRow>
      </FormContent>

      <FormFooter classNames="formFooterBackground">
        <FormRow classNames="footerButtons">
          <Button
            variant="white"
            classNames="cancelButton"
            onClick={onCloseDrawer}
          >
            <FontAwesomeIcon icon={faXmark as IconProp} size="lg" />
            <span>Cancel</span>
          </Button>
          <Button
            type="submit"
            classNames="saveButton"
            isLoading={isSubmitting}
          >
            <FontAwesomeIcon icon={faSave as IconProp} size="lg" />
            <span>&nbsp;Save</span>
          </Button>
        </FormRow>
      </FormFooter>
    </Form>
  );
}

TableDrawerForm.getLayout = DashboardLayout;
